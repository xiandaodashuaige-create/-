const TIKTOK_AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/";
const TIKTOK_TOKEN_URL = "https://open.tiktokapis.com/v2/oauth/token/";
const TIKTOK_SCOPES = ["user.info.basic", "video.publish", "video.upload"].join(",");

type OAuthStateEntry = { customerId: string; expiresAt: number };
const oauthStateStore = new Map<string, OAuthStateEntry>();

function cleanExpiredStates() {
  const now = Date.now();
  for (const [key, val] of oauthStateStore.entries()) {
    if (val.expiresAt < now) oauthStateStore.delete(key);
  }
}

export function generateOAuthState(customerId: string): string {
  cleanExpiredStates();
  const state = crypto.randomUUID();
  oauthStateStore.set(state, {
    customerId,
    expiresAt: Date.now() + 10 * 60 * 1000,
  });
  return state;
}

export function consumeOAuthState(state: string): string | null {
  const entry = oauthStateStore.get(state);
  if (!entry || entry.expiresAt < Date.now()) return null;
  oauthStateStore.delete(state);
  return entry.customerId;
}

export function getTikTokConfig() {
  const clientKey = process.env["TIKTOK_CLIENT_KEY"];
  const clientSecret = process.env["TIKTOK_CLIENT_SECRET"];
  if (!clientKey || !clientSecret) {
    throw new Error("TIKTOK_CLIENT_KEY 或 TIKTOK_CLIENT_SECRET 未配置");
  }
  return { clientKey, clientSecret };
}

export function buildAuthUrl(redirectUri: string, state: string): string {
  const { clientKey } = getTikTokConfig();
  const params = new URLSearchParams({
    client_key: clientKey,
    redirect_uri: redirectUri,
    state,
    scope: TIKTOK_SCOPES,
    response_type: "code",
  });
  return `${TIKTOK_AUTH_URL}?${params}`;
}

export async function exchangeCodeForToken(
  code: string,
  redirectUri: string,
): Promise<{
  access_token: string;
  expires_in: number;
  refresh_token: string;
  refresh_expires_in: number;
  open_id: string;
}> {
  const { clientKey, clientSecret } = getTikTokConfig();

  const res = await fetch(TIKTOK_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_key: clientKey,
      client_secret: clientSecret,
      code,
      grant_type: "authorization_code",
      redirect_uri: redirectUri,
    }),
  });

  const data = await res.json() as Record<string, unknown>;
  if (!res.ok || (data["error"] && data["error"] !== "ok")) {
    throw new Error(`TikTok Token 获取失败: ${JSON.stringify(data)}`);
  }
  return data as Awaited<ReturnType<typeof exchangeCodeForToken>>;
}

export async function refreshAccessToken(
  refreshToken: string,
): Promise<{ access_token: string; expires_in: number; refresh_token: string; refresh_expires_in: number }> {
  const { clientKey, clientSecret } = getTikTokConfig();

  const res = await fetch(TIKTOK_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_key: clientKey,
      client_secret: clientSecret,
      grant_type: "refresh_token",
      refresh_token: refreshToken,
    }),
  });

  const data = await res.json() as Record<string, unknown>;
  if (!res.ok || (data["error"] && data["error"] !== "ok")) {
    throw new Error(`TikTok Token 刷新失败: ${JSON.stringify(data)}`);
  }
  return data as Awaited<ReturnType<typeof refreshAccessToken>>;
}

export async function publishVideoToTikTok(
  accessToken: string,
  videoUrl: string,
  title: string,
  options: { privacyLevel?: string; mode?: "auto" | "direct" | "inbox" } = {},
): Promise<{ publish_id: string; mode: "direct" | "inbox"; note?: string }> {
  const mode = options.mode || "auto";

  const videoRes = await fetch(videoUrl);
  if (!videoRes.ok) {
    throw new Error(`下载视频失败 (${videoRes.status}): ${videoUrl}`);
  }
  const videoBuf = Buffer.from(await videoRes.arrayBuffer());
  const videoSize = videoBuf.length;
  if (videoSize < 5 * 1024) {
    throw new Error(`视频太小（${videoSize} bytes），TikTok 要求最少 5KB`);
  }
  if (videoSize > 64 * 1024 * 1024) {
    throw new Error(`视频太大（${(videoSize / 1024 / 1024).toFixed(1)} MB），当前单分片上传仅支持 ≤ 64MB`);
  }

  async function putBytes(uploadUrl: string) {
    const r = await fetch(uploadUrl, {
      method: "PUT",
      headers: {
        "Content-Type": "video/mp4",
        "Content-Length": String(videoSize),
        "Content-Range": `bytes 0-${videoSize - 1}/${videoSize}`,
      },
      body: videoBuf,
    });
    if (!r.ok) {
      const errBody = await r.text();
      throw new Error(`TikTok 视频字节上传失败 (${r.status}): ${errBody}`);
    }
  }

  async function tryDirect(): Promise<{ publish_id: string; mode: "direct" }> {
    const privacyLevel = options.privacyLevel || "SELF_ONLY";
    const initRes = await fetch("https://open.tiktokapis.com/v2/post/publish/video/init/", {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json; charset=UTF-8" },
      body: JSON.stringify({
        post_info: {
          title: title.slice(0, 2200),
          privacy_level: privacyLevel,
          disable_duet: false,
          disable_comment: false,
          disable_stitch: false,
          video_cover_timestamp_ms: 1000,
        },
        source_info: { source: "FILE_UPLOAD", video_size: videoSize, chunk_size: videoSize, total_chunk_count: 1 },
      }),
    });
    const initData = await initRes.json() as {
      data?: { publish_id?: string; upload_url?: string };
      error?: { code?: string; message?: string };
    };
    if (!initRes.ok || (initData.error?.code && initData.error.code !== "ok")) {
      const err: Error & { code?: string } = new Error(`TikTok Direct init 失败: ${JSON.stringify(initData.error ?? initData)}`);
      err.code = initData.error?.code;
      throw err;
    }
    const { publish_id, upload_url } = initData.data || {};
    if (!publish_id || !upload_url) throw new Error(`TikTok init 响应缺少字段: ${JSON.stringify(initData)}`);
    await putBytes(upload_url);
    return { publish_id, mode: "direct" };
  }

  async function tryInbox(): Promise<{ publish_id: string; mode: "inbox" }> {
    const initRes = await fetch("https://open.tiktokapis.com/v2/post/publish/inbox/video/init/", {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json; charset=UTF-8" },
      body: JSON.stringify({
        source_info: { source: "FILE_UPLOAD", video_size: videoSize, chunk_size: videoSize, total_chunk_count: 1 },
      }),
    });
    const initData = await initRes.json() as {
      data?: { publish_id?: string; upload_url?: string };
      error?: { code?: string; message?: string };
    };
    if (!initRes.ok || (initData.error?.code && initData.error.code !== "ok")) {
      throw new Error(`TikTok Inbox init 失败: ${JSON.stringify(initData.error ?? initData)}`);
    }
    const { publish_id, upload_url } = initData.data || {};
    if (!publish_id || !upload_url) throw new Error(`TikTok inbox init 响应缺少字段: ${JSON.stringify(initData)}`);
    await putBytes(upload_url);
    return { publish_id, mode: "inbox" };
  }

  if (mode === "direct") return tryDirect();
  if (mode === "inbox") {
    const r = await tryInbox();
    return { ...r, note: "已上传到 TikTok 草稿箱，请打开手机 App 确认发布" };
  }

  try {
    return await tryDirect();
  } catch (err: unknown) {
    const e = err as Error & { code?: string };
    const code = e.code ?? "";
    const msg = e.message ?? "";
    const shouldFallback =
      code === "unaudited_client_can_only_post_to_private_accounts" ||
      code === "spam_risk_user_banned_from_posting" ||
      msg.includes("unaudited_client") ||
      msg.includes("private_accounts");
    if (!shouldFallback) throw err;
    const r = await tryInbox();
    return { ...r, note: "Direct Post 受 Sandbox 限制，已自动改为草稿箱模式 — 请打开手机 TikTok App 确认发布" };
  }
}

export async function waitForPublishResult(
  accessToken: string,
  publishId: string,
  opts: { timeoutMs?: number; intervalMs?: number } = {},
): Promise<{ status: string; fail_reason?: string; publicly_available_post_id?: string[]; timedOut?: boolean }> {
  const timeout = opts.timeoutMs ?? 15000;
  const interval = opts.intervalMs ?? 2000;
  const start = Date.now();
  let last = await getPublishStatus(accessToken, publishId);
  while (Date.now() - start < timeout) {
    if (last.status === "PUBLISH_COMPLETE" || last.status === "SEND_TO_USER_INBOX" || last.status === "FAILED") {
      return last;
    }
    await new Promise((r) => setTimeout(r, interval));
    last = await getPublishStatus(accessToken, publishId);
  }
  return { ...last, timedOut: true };
}

export async function getPublishStatus(
  accessToken: string,
  publishId: string,
): Promise<{ status: string; publicly_available_post_id?: string[]; fail_reason?: string }> {
  const res = await fetch("https://open.tiktokapis.com/v2/post/publish/status/fetch/", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json; charset=UTF-8",
    },
    body: JSON.stringify({ publish_id: publishId }),
  });

  const data = await res.json() as {
    data?: { status?: string; publicly_available_post_id?: string[]; fail_reason?: string };
    error?: { code?: string; message?: string };
  };

  if (!res.ok || (data.error?.code && data.error.code !== "ok")) {
    throw new Error(`查询 TikTok 发布状态失败: ${JSON.stringify(data.error ?? data)}`);
  }

  return {
    status: data.data?.status || "UNKNOWN",
    publicly_available_post_id: data.data?.publicly_available_post_id,
    fail_reason: data.data?.fail_reason,
  };
}

export async function getUserInfo(
  accessToken: string,
): Promise<{ open_id: string; display_name: string; avatar_url: string }> {
  const res = await fetch(
    "https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url",
    { headers: { Authorization: `Bearer ${accessToken}` } },
  );
  const data = await res.json() as {
    data?: { user?: Record<string, unknown> };
    error?: { code?: string; message?: string };
  };
  if (!res.ok || (data.error?.code && data.error.code !== "ok")) {
    throw new Error(`获取 TikTok 用户信息失败: ${JSON.stringify(data.error ?? data)}`);
  }
  return data.data?.user as { open_id: string; display_name: string; avatar_url: string };
}
