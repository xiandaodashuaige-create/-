import { Router, type IRouter } from "express";
import healthRouter from "./health";
import accountsRouter from "./accounts";
import competitorsRouter from "./competitors";
import marketDataRouter from "./market-data";
import contentRouter from "./content";
import postsRouter from "./posts";
import analyticsRouter from "./analytics";
import oauthRouter from "./oauth";
import ayrshareRouter from "./ayrshare";
import transcribeRouter from "./transcribe";

const router: IRouter = Router();

router.use(oauthRouter);
router.use(ayrshareRouter);
router.use(transcribeRouter);
router.use(healthRouter);
router.use(accountsRouter);
router.use(competitorsRouter);
router.use(marketDataRouter);
router.use(contentRouter);
router.use(postsRouter);
router.use(analyticsRouter);

export default router;
