import { Router, type IRouter } from "express";
import { db, competitorsTable, competitorPostsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateCompetitorBody,
  DeleteCompetitorParams,
  ListCompetitorPostsParams,
  ListCompetitorsResponse,
  ListCompetitorPostsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/competitors", async (_req, res): Promise<void> => {
  const competitors = await db
    .select()
    .from(competitorsTable)
    .orderBy(competitorsTable.createdAt);
  const sanitized = competitors.map((c) => ({
    ...c,
    pageId: c.pageId ?? undefined,
    pageUrl: c.pageUrl ?? undefined,
    description: c.description ?? undefined,
  }));
  res.json(ListCompetitorsResponse.parse(sanitized));
});

router.post("/competitors", async (req, res): Promise<void> => {
  const parsed = CreateCompetitorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [competitor] = await db
    .insert(competitorsTable)
    .values(parsed.data)
    .returning();
  res.status(201).json(competitor);
});

router.delete("/competitors/:id", async (req, res): Promise<void> => {
  const params = DeleteCompetitorParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(competitorsTable)
    .where(eq(competitorsTable.id, params.data.id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Competitor not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/competitors/:id/posts", async (req, res): Promise<void> => {
  const params = ListCompetitorPostsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const posts = await db
    .select()
    .from(competitorPostsTable)
    .where(eq(competitorPostsTable.competitorId, params.data.id))
    .orderBy(competitorPostsTable.fetchedAt);
  res.json(ListCompetitorPostsResponse.parse(posts));
});

export default router;
