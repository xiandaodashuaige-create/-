import { Router, type IRouter } from "express";
import { db, contentItemsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import OpenAI from "openai";
import {
  CreateContentItemBody,
  DeleteContentItemParams,
  GenerateCaptionBody,
  ListContentItemsQueryParams,
  ListContentItemsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/content", async (req, res): Promise<void> => {
  const parsed = ListContentItemsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { type = "all" } = parsed.data;

  const items = await db
    .select()
    .from(contentItemsTable)
    .orderBy(contentItemsTable.createdAt);

  const filtered = type === "all" ? items : items.filter((i) => i.type === type);
  const sanitized = filtered.map((i) => ({
    ...i,
    caption: i.caption ?? undefined,
    mediaUrl: i.mediaUrl ?? undefined,
    thumbnailUrl: i.thumbnailUrl ?? undefined,
    industry: i.industry ?? undefined,
    tags: i.tags ?? undefined,
    referenceText: i.referenceText ?? undefined,
  }));
  res.json(ListContentItemsResponse.parse(sanitized));
});

router.post("/content", async (req, res): Promise<void> => {
  const parsed = CreateContentItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [item] = await db.insert(contentItemsTable).values(parsed.data).returning();
  res.status(201).json(item);
});

router.delete("/content/:id", async (req, res): Promise<void> => {
  const params = DeleteContentItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(contentItemsTable)
    .where(eq(contentItemsTable.id, params.data.id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Content item not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/content/generate-caption", async (req, res): Promise<void> => {
  const parsed = GenerateCaptionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { industry, product, tone = "promotional", language = "zh", referenceText } = parsed.data;

  const apiKey = process.env["OPENAI_API_KEY"];
  if (!apiKey) {
    res.json({ captions: getMockCaptions(industry, product, tone, language) });
    return;
  }

  try {
    const client = new OpenAI({ apiKey });

    const langInstruction = language === "zh"
      ? "Write in Chinese (Traditional or Simplified as appropriate for the market)."
      : language === "ms"
      ? "Write in Malay (Bahasa Malaysia)."
      : "Write in English.";

    const toneMap: Record<string, string> = {
      promotional: "promotional and sales-focused with urgency",
      educational: "informative and educational",
      engaging: "engaging and conversational with questions",
      casual: "casual, friendly and relatable",
    };

    const prompt = `You are a social media copywriter specializing in local ${industry} businesses.

Generate 4 different Facebook/Instagram captions for the following:
- Industry: ${industry}
- Product/Service: ${product}
- Tone: ${toneMap[tone] || tone}
- ${referenceText ? `Reference content to inspire from (do NOT copy): ${referenceText}` : ""}

${langInstruction}

Requirements:
- Each caption should be 50-150 words
- Include 3-5 relevant hashtags at the end
- Include an emoji at the start
- Include a clear call-to-action
- Make it feel authentic and local (not corporate)

Return ONLY a JSON array of 4 caption strings, nothing else.`;

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0]?.message?.content ?? "{}";
    const parsed2 = JSON.parse(content) as { captions?: string[] };
    const captions = parsed2.captions ?? getMockCaptions(industry, product, tone, language);

    res.json({ captions });
  } catch (err) {
    req.log.error({ err }, "OpenAI caption generation failed");
    res.json({ captions: getMockCaptions(industry, product, tone, language) });
  }
});

function getMockCaptions(industry: string, product: string, tone: string, language: string) {
  if (language === "zh") {
    return [
      `✨ 【${product}专业服务】让您焕然一新！\n我们的${industry}专家为您提供最优质的${product}服务，效果立竿见影。\n现在预约还享受首次优惠20%折扣！\n\n📞 立即联系我们\n\n#${industry} #${product} #美丽变身 #专业服务`,
      `💄 您一直想要的${product}效果，就在这里！\n我们${industry}工作室拥有多年经验，服务过数千名满意顾客。\n亲眼看看我们客户的真实变化！\n📍 方便停车 · 环境舒适\n\n#${industry}专家 #${product} #口碑推荐`,
      `🌟 限时优惠！${product}服务特价中\n专业${industry}团队，贴心服务，让您每次都满意而归。\n⏰ 名额有限，先预约先得！\n\n📲 私信我们预约\n\n#限时优惠 #${product} #${industry}`,
      `💬 客户真实评语：「${product}效果超出预期！」\n您也可以拥有同样的体验。来${industry}专业服务，感受不同！\n第一次来的朋友，享受特别优惠价格。\n\n👇 立即预约\n\n#真实评价 #${industry} #${product}推荐`,
    ];
  }
  return [
    `✨ Transform yourself with our ${product} services at ${industry}! Our experts are ready to give you the look you've always wanted. Book your appointment today and get 20% off! #${industry} #${product} #beauty`,
    `💄 Real results, real people. Our ${product} services speak for themselves. Visit us at ${industry} and experience the difference! Limited slots available. #${product} #${industry} #transformation`,
    `🌟 Special offer on ${product} this week only! Our professional ${industry} team is here to make you shine. Don't miss out — call us to book now! #offer #${industry} #${product}`,
    `💬 "Best ${product} I've ever had!" — our happy customers. Come see why hundreds choose ${industry} for their ${product} needs. First-time customers get a special welcome discount! #happycustomers #${industry} #${product}`,
  ];
}

export default router;
