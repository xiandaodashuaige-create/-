import { Router, type IRouter } from "express";
import { db, socialAccountsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import * as Ayrshare from "../lib/ayrshare";

const router: IRouter = Router();

const DEFAULT_CUSTOMER_ID = "default";

router.get("/social-accounts/ayrshare/status", async (req, res): Promise<void> => {
  if (!Ayrshare.isConfigured()) {
    res.json({
      configured: false,
      facebookLinked: false,
      instagramLinked: false,
      tiktokLinked: false,
      platforms: [],
      displayNames: [],
      dashboardUrl: Ayrshare.getDashboardUrl(),
    });
    return;
  }
  const status = await Ayrshare.getLinkedPlatforms();
  res.json({
    configured: true,
    facebookLinked: status.facebook,
    instagramLinked: status.instagram,
    tiktokLinked: status.tiktok,
    platforms: status.platforms,
    displayNames: status.displayNames,
    dashboardUrl: Ayrshare.getDashboardUrl(),
  });
});

router.post("/social-accounts/ayrshare/sync", async (req, res): Promise<void> => {
  if (!Ayrshare.isConfigured()) {
    res.status(503).json({ error: "AYRSHARE_API_KEY is not configured" });
    return;
  }

  const status = await Ayrshare.getLinkedPlatforms();
  const platforms: Ayrshare.Platform[] = ["facebook", "instagram", "tiktok"];
  const synced: string[] = [];

  for (const platform of platforms) {
    if (!status[platform]) continue;
    const info = status.displayNames.find((d) => d.platform === platform);
    const accountId = `ayrshare_${platform}`;
    const accountName = info?.displayName || info?.username || `${platform} Account`;

    await db
      .insert(socialAccountsTable)
      .values({
        customerId: DEFAULT_CUSTOMER_ID,
        platform,
        accountId,
        accountName,
        accessToken: "ayrshare",
        metadata: {
          username: info?.username ?? null,
          avatarUrl: info?.userImage ?? null,
          source: "ayrshare",
        },
      })
      .onConflictDoUpdate({
        target: [
          socialAccountsTable.customerId,
          socialAccountsTable.platform,
          socialAccountsTable.accountId,
        ],
        set: {
          accountName,
          metadata: {
            username: info?.username ?? null,
            avatarUrl: info?.userImage ?? null,
            source: "ayrshare",
          },
          updatedAt: new Date(),
        },
      });

    synced.push(`${platform}: ${accountName}`);
  }

  res.json({ synced: synced.length, accounts: synced });
});

router.post("/social-accounts/publish", async (req, res): Promise<void> => {
  if (!Ayrshare.isConfigured()) {
    res.status(503).json({ success: false, errorMessage: "AYRSHARE_API_KEY is not configured" });
    return;
  }

  const {
    platforms,
    videoUrl,
    caption,
    hashtags,
    scheduledAt,
    privacyLevel,
  } = req.body as {
    platforms?: string[];
    videoUrl?: string;
    caption?: string;
    hashtags?: string[];
    scheduledAt?: string;
    privacyLevel?: "PUBLIC_TO_EVERYONE" | "MUTUAL_FOLLOW_FRIENDS" | "SELF_ONLY";
  };

  if (!platforms?.length || !videoUrl || !caption) {
    res.status(400).json({ success: false, errorMessage: "platforms, videoUrl, and caption are required" });
    return;
  }

  const validPlatforms = platforms.filter((p): p is Ayrshare.Platform =>
    ["facebook", "instagram", "tiktok"].includes(p)
  );

  if (validPlatforms.length === 0) {
    res.status(400).json({ success: false, errorMessage: "No valid platforms specified" });
    return;
  }

  const linked = await Ayrshare.getLinkedPlatforms();
  const missing = validPlatforms.filter((p) => !linked[p]);
  if (missing.length > 0) {
    res.status(400).json({
      success: false,
      errorMessage: `以下平台未在 Ayrshare 授权: ${missing.join(", ")}`,
      dashboardUrl: Ayrshare.getDashboardUrl(),
    });
    return;
  }

  const result = await Ayrshare.publishToSocial({
    platforms: validPlatforms,
    videoUrl,
    caption,
    hashtags,
    scheduledAt,
    privacyLevel,
  });

  res.status(result.success ? 200 : 502).json(result);
});

router.get("/social-accounts/publish/:postId/status", async (req, res): Promise<void> => {
  const { postId } = req.params as { postId: string };
  const status = await Ayrshare.getPostStatus(postId);
  res.json(status);
});

router.delete("/social-accounts/publish/:postId", async (req, res): Promise<void> => {
  const { postId } = req.params as { postId: string };
  const ok = await Ayrshare.cancelScheduledPost(postId);
  res.json({ success: ok });
});

export default router;
