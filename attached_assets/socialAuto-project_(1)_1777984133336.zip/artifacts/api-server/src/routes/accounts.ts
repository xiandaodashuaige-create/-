import { Router, type IRouter } from "express";
import { db, socialAccountsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateAccountBody,
  DeleteAccountParams,
  ListAccountsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/accounts", async (req, res): Promise<void> => {
  const accounts = await db
    .select()
    .from(socialAccountsTable)
    .orderBy(socialAccountsTable.createdAt);
  const sanitized = accounts.map((a) => ({
    ...a,
    tokenExpiresAt: a.tokenExpiresAt ?? undefined,
  }));
  res.json(ListAccountsResponse.parse(sanitized));
});

router.post("/accounts", async (req, res): Promise<void> => {
  const parsed = CreateAccountBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [account] = await db
    .insert(socialAccountsTable)
    .values({
      customerId: "default",
      platform: parsed.data.platform,
      accountId: parsed.data.accountId,
      accountName: parsed.data.accountName,
      accessToken: "",
    })
    .returning();
  res.status(201).json(account);
});

router.delete("/accounts/:id", async (req, res): Promise<void> => {
  const params = DeleteAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(socialAccountsTable)
    .where(eq(socialAccountsTable.id, params.data.id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
