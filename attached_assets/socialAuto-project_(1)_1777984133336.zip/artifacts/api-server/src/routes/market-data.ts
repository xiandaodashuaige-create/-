import { Router, type IRouter } from "express";
import { SearchAdLibraryQueryParams, GetTrendingContentQueryParams } from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.get("/market-data/ads", async (req, res): Promise<void> => {
  const parsed = SearchAdLibraryQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { keyword, country = "ALL" } = parsed.data;
  const token = process.env["FACEBOOK_ACCESS_TOKEN"];

  if (!token) {
    res.json(getMockAds(keyword));
    return;
  }

  try {
    const url = new URL("https://graph.facebook.com/v19.0/ads_archive");
    url.searchParams.set("search_terms", keyword);
    url.searchParams.set("ad_reached_countries", `["${country}"]`);
    url.searchParams.set("ad_type", "ALL");
    url.searchParams.set("fields", "id,page_name,ad_creative_body,ad_snapshot_url,ad_delivery_start_time,publisher_platforms");
    url.searchParams.set("limit", "20");
    url.searchParams.set("access_token", token);

    const resp = await fetch(url.toString());
    const data = await resp.json() as { data?: unknown[] };

    if (!resp.ok || !data.data) {
      res.json(getMockAds(keyword));
      return;
    }

    const ads = (data.data as Array<Record<string, unknown>>).map((ad) => ({
      id: String(ad["id"] ?? ""),
      advertiserName: String(ad["page_name"] ?? "Unknown"),
      caption: String(ad["ad_creative_body"] ?? ""),
      mediaType: "image",
      mediaUrl: String(ad["ad_snapshot_url"] ?? ""),
      startDate: String(ad["ad_delivery_start_time"] ?? ""),
      platforms: Array.isArray(ad["publisher_platforms"]) ? ad["publisher_platforms"] as string[] : ["facebook"],
      ctaType: "LEARN_MORE",
    }));

    res.json(ads);
  } catch {
    res.json(getMockAds(keyword));
  }
});

router.get("/market-data/trending", async (req, res): Promise<void> => {
  const parsed = GetTrendingContentQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { industry, region = "MY" } = parsed.data;
  const tikHubToken = process.env["TIKHUB_API_KEY"];

  if (!tikHubToken) {
    res.json(getMockTrending(industry, region));
    return;
  }

  try {
    const resp = await fetch(
      `https://api.tikhub.io/api/v1/tiktok/app/v3/fetch_trending_hashtag_videos?keyword=${encodeURIComponent(industry || "beauty")}&region=${region}&count=20`,
      {
        headers: {
          Authorization: `Bearer ${tikHubToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (!resp.ok) {
      res.json(getMockTrending(industry, region));
      return;
    }

    const data = await resp.json() as { data?: { videos?: Array<Record<string, unknown>> } };
    const videos = data.data?.videos ?? [];

    const items = videos.map((v) => ({
      id: String(v["id"] ?? ""),
      platform: "tiktok",
      title: String(v["desc"] ?? ""),
      description: String(v["desc"] ?? ""),
      videoUrl: String((v["video"] as Record<string, unknown>)?.["play_addr"] ?? ""),
      thumbnailUrl: String((v["video"] as Record<string, unknown>)?.["cover"] ?? ""),
      likes: Number(v["digg_count"] ?? 0),
      views: Number(v["play_count"] ?? 0),
      hashtags: [],
      authorName: String((v["author"] as Record<string, unknown>)?.["nickname"] ?? ""),
    }));

    res.json(items);
  } catch {
    res.json(getMockTrending(industry, region));
  }
});

// ── EchoTik competitor analysis ──────────────────────────────────────
router.get("/market-data/echotik", async (req, res): Promise<void> => {
  const { keyword = "beauty", region = "MY", type = "trending" } = req.query as {
    keyword?: string;
    region?: string;
    type?: "trending" | "competitor";
  };

  const apiKey = process.env["ECHOTIK_API_KEY"];

  if (!apiKey) {
    logger.warn("ECHOTIK_API_KEY not configured, returning mock data");
    res.json(getMockEchoTik(keyword, region));
    return;
  }

  try {
    const endpoint = type === "competitor"
      ? `https://echotik.live/api/v1/creators/search?keyword=${encodeURIComponent(keyword)}&region=${region}&page=1&page_size=20`
      : `https://echotik.live/api/v1/videos/trending?region=${region}&category=${encodeURIComponent(keyword)}&page=1&page_size=20`;

    const resp = await fetch(endpoint, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
    });

    if (!resp.ok) {
      logger.warn({ status: resp.status }, "EchoTik API error, falling back to mock");
      res.json(getMockEchoTik(keyword, region));
      return;
    }

    const data = await resp.json() as Record<string, unknown>;

    if (type === "competitor") {
      const creators = (data["data"] as Array<Record<string, unknown>> ?? []).map((c) => ({
        id: String(c["id"] ?? ""),
        platform: "tiktok",
        name: String(c["nickname"] ?? ""),
        handle: String(c["unique_id"] ?? ""),
        avatarUrl: String(c["avatar"] ?? ""),
        followers: Number(c["follower_count"] ?? 0),
        avgViews: Number(c["avg_views"] ?? 0),
        engagementRate: Number(c["engagement_rate"] ?? 0),
        category: String(c["category"] ?? keyword),
        region,
      }));
      res.json({ type: "competitor", items: creators });
    } else {
      const videos = (data["data"] as Array<Record<string, unknown>> ?? []).map((v) => ({
        id: String(v["id"] ?? ""),
        platform: "tiktok",
        title: String(v["desc"] ?? ""),
        authorName: String(v["author_nickname"] ?? ""),
        authorHandle: String(v["author_unique_id"] ?? ""),
        thumbnailUrl: String(v["cover"] ?? ""),
        videoUrl: String(v["play_url"] ?? ""),
        likes: Number(v["digg_count"] ?? 0),
        views: Number(v["play_count"] ?? 0),
        comments: Number(v["comment_count"] ?? 0),
        shares: Number(v["share_count"] ?? 0),
        hashtags: (v["hashtags"] as string[] ?? []),
        duration: Number(v["duration"] ?? 0),
      }));
      res.json({ type: "trending", items: videos });
    }
  } catch (err) {
    logger.error({ err }, "EchoTik API request failed");
    res.json(getMockEchoTik(keyword, region));
  }
});

// ── Social Crawl: Xiaohongshu + Douyin trending (MediaCrawler-inspired) ──
router.get("/market-data/social-crawl", async (req, res): Promise<void> => {
  const {
    platform = "xhs",
    keyword = "美容",
    limit = "12",
  } = req.query as { platform?: string; keyword?: string; limit?: string };

  const pageSize = Math.min(Number(limit) || 12, 30);

  try {
    if (platform === "douyin") {
      // Douyin public hot-search billboard (no auth required)
      const resp = await fetch(
        "https://www.iesdouyin.com/web/api/v2/hotsearch/billboard/word/?type_id=24&count=30",
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            Referer: "https://www.douyin.com/",
            Accept: "application/json, text/plain, */*",
          },
          signal: AbortSignal.timeout(6000),
        },
      );

      if (resp.ok) {
        const data = (await resp.json()) as {
          word_list?: Array<{ word: string; hot_value: number; label?: number }>;
        };
        const words = (data.word_list ?? []).slice(0, pageSize);
        const items = words.map((w, i) => ({
          id: `douyin_hot_${i}`,
          platform: "douyin",
          type: "hot_search",
          title: w.word,
          hotValue: w.hot_value,
          label: w.label === 1 ? "新" : w.label === 2 ? "热" : w.label === 3 ? "爆" : "",
          likes: w.hot_value,
          views: w.hot_value * 10,
          comments: Math.floor(w.hot_value / 50),
          thumbnailUrl: `https://picsum.photos/seed/dy${i}/300/400`,
          hashtags: [`#${w.word}`],
          authorName: "",
        }));
        res.json({ platform: "douyin", keyword, source: "live", items });
        return;
      }
    }

    if (platform === "xhs") {
      // Xiaohongshu public search (official web API, requires valid session cookie for personalized results)
      const resp = await fetch(
        `https://edith.xiaohongshu.com/api/sns/web/v1/search/notes?keyword=${encodeURIComponent(keyword)}&page=1&page_size=${pageSize}&search_id=&sort=general&note_type=0`,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15",
            Referer: "https://www.xiaohongshu.com/",
            Accept: "application/json",
          },
          signal: AbortSignal.timeout(6000),
        },
      );

      if (resp.ok) {
        const data = (await resp.json()) as {
          data?: {
            items?: Array<{
              id: string;
              display_title: string;
              user?: { nickname: string };
              interact_info?: { liked_count: string; comment_count: string };
              cover?: { url: string };
              tag_list?: Array<{ name: string }>;
            }>;
          };
        };
        const notes = data.data?.items ?? [];
        if (notes.length > 0) {
          const items = notes.map((n) => ({
            id: n.id,
            platform: "xhs",
            type: "note",
            title: n.display_title,
            authorName: n.user?.nickname ?? "",
            likes: Number(n.interact_info?.liked_count ?? 0),
            views: Number(n.interact_info?.liked_count ?? 0) * 8,
            comments: Number(n.interact_info?.comment_count ?? 0),
            thumbnailUrl: n.cover?.url ?? `https://picsum.photos/seed/xhs${n.id}/300/400`,
            hashtags: (n.tag_list ?? []).map((t) => `#${t.name}`),
          }));
          res.json({ platform: "xhs", keyword, source: "live", items });
          return;
        }
      }
    }
  } catch (err) {
    logger.warn({ err, platform }, "Social crawl request failed, falling back to mock");
  }

  // Fallback mock data (rich, bilingual-friendly)
  res.json(getMockSocialCrawl(platform, keyword, pageSize));
});

function getMockSocialCrawl(platform: string, keyword: string, limit: number) {
  const tag = keyword || "美容";
  if (platform === "douyin") {
    const hotWords = [
      { word: `${tag}教程`, hotValue: 9820000, label: "爆" },
      { word: `${tag}推荐`, hotValue: 7430000, label: "热" },
      { word: `${tag}变美`, hotValue: 6210000, label: "热" },
      { word: `${tag}护肤`, hotValue: 5880000, label: "新" },
      { word: `平价${tag}`, hotValue: 4990000, label: "" },
      { word: `${tag}合集`, hotValue: 4120000, label: "新" },
      { word: `学生党${tag}`, hotValue: 3560000, label: "" },
      { word: `${tag}打卡`, hotValue: 2940000, label: "" },
      { word: `${tag}测评`, hotValue: 2310000, label: "" },
      { word: `${tag}好物`, hotValue: 1980000, label: "" },
      { word: `${tag}分享`, hotValue: 1650000, label: "" },
      { word: `${tag}vlog`, hotValue: 1230000, label: "" },
    ].slice(0, limit);
    return {
      platform: "douyin",
      keyword,
      source: "mock",
      note: "Real data requires Douyin API access. Configure DOUYIN_COOKIE in Secrets.",
      items: hotWords.map((w, i) => ({
        id: `douyin_mock_${i}`,
        platform: "douyin",
        type: "hot_search",
        title: w.word,
        hotValue: w.hotValue,
        label: w.label,
        likes: w.hotValue,
        views: w.hotValue * 10,
        comments: Math.floor(w.hotValue / 50),
        thumbnailUrl: `https://picsum.photos/seed/dy${tag}${i}/300/400`,
        hashtags: [`#${w.word}`],
        authorName: "",
      })),
    };
  }

  // XHS mock
  const notes = Array.from({ length: limit }, (_, i) => ({
    id: `xhs_mock_${i}`,
    platform: "xhs",
    type: "note",
    title: [
      `${tag}这样做，皮肤好到发光 ✨`,
      `平价${tag}好物分享｜学生党必看`,
      `${tag}变美日记 Day ${i + 1}`,
      `我的${tag}秘诀，同事都在追问`,
      `${tag}测评｜买了这么多终于找到最好用的`,
      `${tag}入门指南，手残党也能学会`,
      `${tag}+护肤二合一，省钱又有效`,
      `分享我的${tag}日常，坚持3个月的变化`,
    ][i % 8],
    authorName: [`小美日记`, `护肤研究所`, `${tag}达人`, `美妆博主`, `爱美的你`][i % 5],
    likes: Math.floor(50000 + Math.random() * 200000),
    views: Math.floor(500000 + Math.random() * 2000000),
    comments: Math.floor(500 + Math.random() * 5000),
    thumbnailUrl: `https://picsum.photos/seed/xhs${tag}${i}/300/400`,
    hashtags: [`#${tag}`, `#护肤`, `#变美`, `#种草`],
  }));
  return {
    platform: "xhs",
    keyword,
    source: "mock",
    note: "Real data requires Xiaohongshu session cookie. Configure XHS_COOKIE in Secrets.",
    items: notes,
  };
}

// ── Best posting times by platform ───────────────────────────────────
router.get("/market-data/best-times", async (_req, res): Promise<void> => {
  res.json({
    facebook: {
      bestDays: ["Tuesday", "Wednesday", "Thursday"],
      bestHours: [9, 13, 15],
      timezone: "local",
      insight: "Posts between 1pm–3pm on weekdays get 18% more engagement",
    },
    instagram: {
      bestDays: ["Monday", "Tuesday", "Wednesday", "Friday"],
      bestHours: [6, 12, 19],
      timezone: "local",
      insight: "Reels posted at 6am or 7pm outperform other slots by 23%",
    },
    tiktok: {
      bestDays: ["Tuesday", "Thursday", "Friday"],
      bestHours: [19, 20, 21],
      timezone: "local",
      insight: "Videos posted 7pm–9pm on Tue/Thu/Fri see 2× higher completion rates",
    },
  });
});

// ── Mock data helpers ─────────────────────────────────────────────────

function getMockAds(keyword: string) {
  return [
    {
      id: "ad_001",
      advertiserName: `${keyword} Beauty Studio`,
      caption: `🌟 Transform your look with our professional ${keyword} services! Book now and get 20% off your first session. Limited spots available!`,
      mediaType: "image",
      mediaUrl: "https://picsum.photos/seed/beauty1/400/300",
      startDate: "2024-01-15",
      platforms: ["facebook", "instagram"],
      ctaType: "BOOK_NOW",
    },
    {
      id: "ad_002",
      advertiserName: `Premium ${keyword} Salon`,
      caption: `✨ New year, new you! Our ${keyword} experts are ready to give you the look you've always wanted. Visit us today!`,
      mediaType: "image",
      mediaUrl: "https://picsum.photos/seed/beauty2/400/300",
      startDate: "2024-01-10",
      platforms: ["facebook"],
      ctaType: "LEARN_MORE",
    },
    {
      id: "ad_003",
      advertiserName: `${keyword} & More`,
      caption: `💅 Professional ${keyword} services at affordable prices. Walk-ins welcome! Call us to schedule your appointment.`,
      mediaType: "video",
      mediaUrl: "https://picsum.photos/seed/beauty3/400/300",
      startDate: "2024-02-01",
      platforms: ["facebook", "instagram"],
      ctaType: "CALL_NOW",
    },
  ];
}

function getMockTrending(industry: string | undefined, _region: string) {
  const tag = industry || "beauty";
  return [
    {
      id: "trend_001",
      platform: "tiktok",
      title: `Amazing ${tag} transformation that went viral`,
      description: `This ${tag} content got 2M views in 24 hours. The secret? Authentic before/after content!`,
      videoUrl: "",
      thumbnailUrl: `https://picsum.photos/seed/${tag}1/300/400`,
      likes: 245000,
      views: 2100000,
      hashtags: [`#${tag}`, "#viral", "#transformation"],
      authorName: `${tag}_expert`,
    },
    {
      id: "trend_002",
      platform: "tiktok",
      title: `${tag} tips you didn't know about`,
      description: `Educational ${tag} content performs 3x better on weekdays. Post between 6-9pm for max reach.`,
      videoUrl: "",
      thumbnailUrl: `https://picsum.photos/seed/${tag}2/300/400`,
      likes: 89000,
      views: 780000,
      hashtags: [`#${tag}tips`, "#howto", "#tutorial"],
      authorName: `${tag}_pro`,
    },
    {
      id: "trend_003",
      platform: "tiktok",
      title: `Day in the life at a ${tag} business`,
      description: `Behind-the-scenes content builds trust. Show your process, your team, your workspace!`,
      videoUrl: "",
      thumbnailUrl: `https://picsum.photos/seed/${tag}3/300/400`,
      likes: 156000,
      views: 1340000,
      hashtags: [`#${tag}life`, "#behindthescenes", "#smallbusiness"],
      authorName: `${tag}_studio`,
    },
  ];
}

function getMockEchoTik(keyword: string, region: string) {
  const tag = keyword || "beauty";
  return {
    type: "trending",
    configured: false,
    note: "Add ECHOTIK_API_KEY to Secrets to enable real EchoTik data",
    items: [
      {
        id: "echo_001",
        platform: "tiktok",
        title: `#${tag} 最新爆款视频 — 3天涨粉10万`,
        authorName: `${tag}达人`,
        authorHandle: `@${tag}_creator`,
        thumbnailUrl: `https://picsum.photos/seed/echo${tag}1/300/400`,
        videoUrl: "",
        likes: 328000,
        views: 4200000,
        comments: 12400,
        shares: 89000,
        hashtags: [`#${tag}`, "#爆款", "#种草"],
        duration: 45,
        region,
      },
      {
        id: "echo_002",
        platform: "tiktok",
        title: `${tag}行业同款内容，互动率高达 8.7%`,
        authorName: `${tag}专业号`,
        authorHandle: `@${tag}_pro`,
        thumbnailUrl: `https://picsum.photos/seed/echo${tag}2/300/400`,
        videoUrl: "",
        likes: 156000,
        views: 1790000,
        comments: 5600,
        shares: 34000,
        hashtags: [`#${tag}技巧`, "#干货", "#美业"],
        duration: 60,
        region,
      },
      {
        id: "echo_003",
        platform: "tiktok",
        title: `实拍 ${tag} 门店日常，真实感最吸粉`,
        authorName: `${tag}小店`,
        authorHandle: `@${tag}_shop`,
        thumbnailUrl: `https://picsum.photos/seed/echo${tag}3/300/400`,
        videoUrl: "",
        likes: 94000,
        views: 980000,
        comments: 3200,
        shares: 18000,
        hashtags: [`#${tag}日常`, "#探店", "#vlog"],
        duration: 35,
        region,
      },
    ],
  };
}

export default router;
