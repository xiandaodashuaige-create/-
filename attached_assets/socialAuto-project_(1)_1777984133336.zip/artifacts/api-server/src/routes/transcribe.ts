import { Router, type IRouter } from "express";
import express from "express";
import OpenAI from "openai";
import { toFile } from "openai";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.post(
  "/transcribe",
  express.raw({ type: "*/*", limit: "60mb" }),
  async (req, res): Promise<void> => {
    const rawCT = req.headers["content-type"] || "video/mp4";
    const mimeType = rawCT.split(";")[0].trim();
    const filename =
      (req.headers["x-filename"] as string | undefined) ||
      `audio.${mimeType.split("/")[1] || "mp4"}`;
    const language = (req.headers["x-language"] as string | undefined) || undefined;
    const urlInput = req.headers["x-url"] as string | undefined;

    const apiKey = process.env["OPENAI_API_KEY"];
    if (!apiKey) {
      logger.warn("OPENAI_API_KEY not configured — returning mock Whisper transcription");
      res.json({
        text: "（示例转录）感谢大家关注我们的美容沙龙！今天为大家介绍最新护肤套餐，包含深层清洁、补水保湿和美白提亮三个步骤，限时优惠 8 折，扫码预约享折扣！#美容 #护肤 #优惠",
        language: language || "zh",
        mock: true,
        note: "Add OPENAI_API_KEY to Secrets to enable real Whisper transcription",
      });
      return;
    }

    const openai = new OpenAI({ apiKey });

    try {
      let buffer: Buffer;

      if (urlInput) {
        const resp = await fetch(urlInput);
        if (!resp.ok) {
          res.status(400).json({ error: "Failed to fetch audio from URL" });
          return;
        }
        buffer = Buffer.from(await resp.arrayBuffer());
      } else {
        buffer = req.body as Buffer;
        if (!buffer || buffer.length === 0) {
          res.status(400).json({ error: "No audio data provided in request body" });
          return;
        }
      }

      const file = await toFile(buffer, filename, { type: mimeType });

      const transcription = await openai.audio.transcriptions.create({
        file,
        model: "whisper-1",
        language,
      });

      req.log.info(
        { chars: transcription.text.length, language },
        "Whisper transcription completed",
      );
      res.json({ text: transcription.text, language: language || "auto", mock: false });
    } catch (err) {
      logger.error({ err }, "Whisper transcription failed");
      res.status(500).json({ error: "Transcription failed — check OPENAI_API_KEY and file format" });
    }
  },
);

export default router;
