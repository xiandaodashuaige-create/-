import { Router, type IRouter } from "express";
import { db, socialAccountsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import * as MetaOAuth from "../lib/meta-oauth";
import * as TikTokOAuth from "../lib/tiktok-oauth";

const router: IRouter = Router();

const DEFAULT_CUSTOMER_ID = "default";

function getBaseUrl(_req: { headers: { host?: string; "x-forwarded-proto"?: string } }): string {
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) {
    const primary = domains.split(",")[0].trim();
    return `https://${primary}`;
  }
  const devDomain = process.env["REPLIT_DEV_DOMAIN"];
  if (devDomain) return `https://${devDomain}`;
  return "http://localhost:80";
}

router.get("/oauth/status", async (req, res) => {
  const metaOk = !!(process.env["META_APP_ID"] && process.env["META_APP_SECRET"]);
  const tiktokOk = !!(process.env["TIKTOK_CLIENT_KEY"] && process.env["TIKTOK_CLIENT_SECRET"]);

  let accounts: (typeof socialAccountsTable.$inferSelect)[] = [];
  try {
    const { customerId } = req.query as { customerId?: string };
    accounts = customerId
      ? await db.select().from(socialAccountsTable).where(eq(socialAccountsTable.customerId, customerId))
      : await db.select().from(socialAccountsTable);
  } catch {
    // DB not migrated yet
  }

  res.json({
    configured: {
      meta: metaOk,
      tiktok: tiktokOk,
      message: [
        metaOk ? "✅ Meta (Facebook/Instagram) 已配置" : "❌ Meta 未配置（需要 META_APP_ID + META_APP_SECRET）",
        tiktokOk ? "✅ TikTok 已配置" : "❌ TikTok 未配置（需要 TIKTOK_CLIENT_KEY + TIKTOK_CLIENT_SECRET）",
      ],
    },
    authorizedAccounts: accounts.map((a) => ({
      id: a.id,
      customerId: a.customerId,
      platform: a.platform,
      accountName: a.accountName,
      accountId: a.accountId,
      connectedAt: a.createdAt,
      tokenExpires: a.tokenExpiresAt,
    })),
  });
});

router.get("/oauth/facebook/connect", (req, res) => {
  const { customerId = DEFAULT_CUSTOMER_ID, json } = req.query as { customerId?: string; json?: string };
  try {
    const base = getBaseUrl(req);
    const redirectUri = `${base}/api/oauth/facebook/callback`;
    const state = MetaOAuth.generateOAuthState(customerId);
    const authUrl = MetaOAuth.buildAuthUrl(redirectUri, state);
    if (json === "1") {
      res.json({ authUrl, redirectUri });
      return;
    }
    res.redirect(authUrl);
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

router.get("/oauth/facebook/callback", async (req, res) => {
  const { code, state, error } = req.query as { code?: string; state?: string; error?: string };

  if (error) {
    res.send(`<html><head><meta charset="utf-8"></head><body style="font-family:sans-serif;padding:40px;text-align:center"><h2>授权取消</h2><p>${error}</p><script>setTimeout(()=>window.close(),2000)</script></body></html>`);
    return;
  }
  if (!code || !state) {
    res.status(400).send("<h2>缺少参数</h2>");
    return;
  }

  const customerId = MetaOAuth.consumeOAuthState(state);
  if (!customerId) {
    res.status(400).send("<h2>授权已过期，请重新连接</h2>");
    return;
  }

  try {
    const base = getBaseUrl(req);
    const redirectUri = `${base}/api/oauth/facebook/callback`;

    const { access_token: shortToken } = await MetaOAuth.exchangeCodeForToken(code, redirectUri);
    const longToken = await MetaOAuth.getLongLivedToken(shortToken);
    const pages = await MetaOAuth.getUserPages(longToken);

    const saved: string[] = [];

    for (const page of pages) {
      await db
        .insert(socialAccountsTable)
        .values({
          customerId,
          platform: "facebook",
          accountId: page.id,
          accountName: page.name,
          accessToken: page.access_token,
          tokenExpiresAt: null,
          metadata: { category: page.category },
        })
        .onConflictDoUpdate({
          target: [socialAccountsTable.customerId, socialAccountsTable.platform, socialAccountsTable.accountId],
          set: {
            accountName: page.name,
            accessToken: page.access_token,
            updatedAt: new Date(),
          },
        });
      saved.push(`Facebook: ${page.name}`);

      if (page.instagram_business_account?.id) {
        const igId = page.instagram_business_account.id;
        const igInfo = await MetaOAuth.getInstagramAccount(page.id, page.access_token);
        const igName = igInfo?.username ?? igInfo?.name ?? `ig_${igId}`;

        await db
          .insert(socialAccountsTable)
          .values({
            customerId,
            platform: "instagram",
            accountId: igId,
            accountName: igName,
            accessToken: page.access_token,
            tokenExpiresAt: null,
            metadata: { linkedFacebookPageId: page.id },
          })
          .onConflictDoUpdate({
            target: [socialAccountsTable.customerId, socialAccountsTable.platform, socialAccountsTable.accountId],
            set: {
              accountName: igName,
              accessToken: page.access_token,
              updatedAt: new Date(),
            },
          });
        saved.push(`Instagram: @${igName}`);
      }
    }

    res.send(`
      <html><head><meta charset="utf-8"></head><body style="font-family:sans-serif;padding:40px;text-align:center">
        <h2>✅ 授权成功！</h2>
        <p>以下账号已连接：</p>
        <ul style="list-style:none;padding:0">${saved.map((s) => `<li>✅ ${s}</li>`).join("")}</ul>
        <p style="color:#888;margin-top:20px">此页面将自动关闭…</p>
        <script>setTimeout(()=>window.close(),3000)</script>
      </body></html>
    `);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    req.log.error({ err }, "Facebook OAuth callback failed");
    res.status(500).send(`<html><head><meta charset="utf-8"></head><body style="font-family:sans-serif;padding:40px"><h2>授权失败</h2><pre>${msg}</pre></body></html>`);
  }
});

router.get("/oauth/tiktok/connect", (req, res) => {
  const { customerId = DEFAULT_CUSTOMER_ID, json } = req.query as { customerId?: string; json?: string };
  try {
    const base = getBaseUrl(req);
    const redirectUri = `${base}/api/oauth/tiktok/callback`;
    const state = TikTokOAuth.generateOAuthState(customerId);
    const authUrl = TikTokOAuth.buildAuthUrl(redirectUri, state);
    if (json === "1") {
      res.json({ authUrl, redirectUri });
      return;
    }
    res.redirect(authUrl);
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

router.get("/oauth/tiktok/callback", async (req, res) => {
  const { code, state, error } = req.query as { code?: string; state?: string; error?: string };

  if (error) {
    res.send(`<html><head><meta charset="utf-8"></head><body style="font-family:sans-serif;padding:40px;text-align:center"><h2>授权取消</h2><p>${error}</p><script>setTimeout(()=>window.close(),2000)</script></body></html>`);
    return;
  }
  if (!code || !state) {
    res.status(400).send("<h2>缺少参数</h2>");
    return;
  }

  const customerId = TikTokOAuth.consumeOAuthState(state);
  if (!customerId) {
    res.status(400).send("<h2>授权已过期，请重新连接</h2>");
    return;
  }

  try {
    const base = getBaseUrl(req);
    const redirectUri = `${base}/api/oauth/tiktok/callback`;

    const tokenData = await TikTokOAuth.exchangeCodeForToken(code, redirectUri);
    const userInfo = await TikTokOAuth.getUserInfo(tokenData.access_token);

    const expiresAt = new Date(Date.now() + tokenData.expires_in * 1000);
    const refreshExpiresAt = new Date(Date.now() + tokenData.refresh_expires_in * 1000);

    await db
      .insert(socialAccountsTable)
      .values({
        customerId,
        platform: "tiktok",
        accountId: tokenData.open_id,
        accountName: userInfo.display_name,
        accessToken: tokenData.access_token,
        tokenExpiresAt: expiresAt,
        refreshToken: tokenData.refresh_token,
        metadata: {
          avatarUrl: userInfo.avatar_url,
          refreshExpiresAt: refreshExpiresAt.toISOString(),
        },
      })
      .onConflictDoUpdate({
        target: [socialAccountsTable.customerId, socialAccountsTable.platform, socialAccountsTable.accountId],
        set: {
          accountName: userInfo.display_name,
          accessToken: tokenData.access_token,
          tokenExpiresAt: expiresAt,
          refreshToken: tokenData.refresh_token,
          updatedAt: new Date(),
        },
      });

    res.send(`
      <html><head><meta charset="utf-8"></head><body style="font-family:sans-serif;padding:40px;text-align:center">
        <h2>✅ TikTok 授权成功！</h2>
        <p>已连接账号：<strong>@${userInfo.display_name}</strong></p>
        <p style="color:#888;margin-top:20px">此页面将自动关闭…</p>
        <script>setTimeout(()=>window.close(),3000)</script>
      </body></html>
    `);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    req.log.error({ err }, "TikTok OAuth callback failed");
    res.status(500).send(`<html><head><meta charset="utf-8"></head><body style="font-family:sans-serif;padding:40px"><h2>TikTok 授权失败</h2><pre>${msg}</pre></body></html>`);
  }
});

router.delete("/oauth/disconnect", async (req, res) => {
  const { customerId, platform, accountId } = req.body as {
    customerId?: string;
    platform?: string;
    accountId?: string;
  };

  if (!customerId || !platform || !accountId) {
    res.status(400).json({ error: "customerId、platform 和 accountId 为必填项" });
    return;
  }

  await db
    .delete(socialAccountsTable)
    .where(
      and(
        eq(socialAccountsTable.customerId, customerId),
        eq(socialAccountsTable.platform, platform),
        eq(socialAccountsTable.accountId, accountId),
      ),
    );

  res.json({ success: true, message: `已断开 ${platform} 账号 ${accountId}` });
});

export default router;
