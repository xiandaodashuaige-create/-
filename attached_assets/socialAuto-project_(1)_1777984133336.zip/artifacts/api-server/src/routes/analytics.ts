import { Router, type IRouter } from "express";
import { db, socialAccountsTable, competitorsTable, contentItemsTable, scheduledPostsTable, publishLogsTable } from "@workspace/db";
import { count, eq, gte, sql } from "drizzle-orm";
import { GetAnalyticsSummaryResponse, GetPublishHistoryResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/analytics/summary", async (_req, res): Promise<void> => {
  const [totalAccounts] = await db.select({ count: count() }).from(socialAccountsTable);
  const [totalCompetitors] = await db.select({ count: count() }).from(competitorsTable);
  const [totalContentItems] = await db.select({ count: count() }).from(contentItemsTable);
  const [totalScheduledPosts] = await db.select({ count: count() }).from(scheduledPostsTable);

  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

  const [publishedThisWeek] = await db
    .select({ count: count() })
    .from(scheduledPostsTable)
    .where(
      sql`${scheduledPostsTable.status} = 'published' AND ${scheduledPostsTable.publishedAt} >= ${oneWeekAgo}`
    );

  const [failedPosts] = await db
    .select({ count: count() })
    .from(scheduledPostsTable)
    .where(eq(scheduledPostsTable.status, "failed"));

  const [upcomingPosts] = await db
    .select({ count: count() })
    .from(scheduledPostsTable)
    .where(
      sql`${scheduledPostsTable.status} = 'scheduled' AND ${scheduledPostsTable.scheduledAt} >= NOW()`
    );

  const contentCounts = await db
    .select({ type: contentItemsTable.type, count: count() })
    .from(contentItemsTable)
    .groupBy(contentItemsTable.type);

  const statusCounts = await db
    .select({ status: scheduledPostsTable.status, count: count() })
    .from(scheduledPostsTable)
    .groupBy(scheduledPostsTable.status);

  const contentByType = { text: 0, image: 0, video: 0 };
  for (const row of contentCounts) {
    if (row.type === "text") contentByType.text = Number(row.count);
    if (row.type === "image") contentByType.image = Number(row.count);
    if (row.type === "video") contentByType.video = Number(row.count);
  }

  const postsByStatus = { draft: 0, scheduled: 0, published: 0, failed: 0 };
  for (const row of statusCounts) {
    if (row.status === "draft") postsByStatus.draft = Number(row.count);
    if (row.status === "scheduled") postsByStatus.scheduled = Number(row.count);
    if (row.status === "published") postsByStatus.published = Number(row.count);
    if (row.status === "failed") postsByStatus.failed = Number(row.count);
  }

  res.json(
    GetAnalyticsSummaryResponse.parse({
      totalAccounts: Number(totalAccounts?.count ?? 0),
      totalCompetitors: Number(totalCompetitors?.count ?? 0),
      totalContentItems: Number(totalContentItems?.count ?? 0),
      totalScheduledPosts: Number(totalScheduledPosts?.count ?? 0),
      publishedThisWeek: Number(publishedThisWeek?.count ?? 0),
      failedPosts: Number(failedPosts?.count ?? 0),
      upcomingPosts: Number(upcomingPosts?.count ?? 0),
      contentByType,
      postsByStatus,
    })
  );
});

router.get("/analytics/publish-history", async (_req, res): Promise<void> => {
  const logs = await db
    .select()
    .from(publishLogsTable)
    .orderBy(sql`${publishLogsTable.publishedAt} DESC`)
    .limit(50);
  const sanitized = logs.map((l) => ({
    ...l,
    errorMessage: l.errorMessage ?? undefined,
    ayrsharePostId: l.ayrsharePostId ?? undefined,
  }));
  res.json(GetPublishHistoryResponse.parse(sanitized));
});

export default router;
