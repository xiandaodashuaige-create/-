import { Router, type IRouter } from "express";
import { db, scheduledPostsTable, publishLogsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreatePostBody,
  UpdatePostBody,
  GetPostParams,
  UpdatePostParams,
  DeletePostParams,
  PublishPostParams,
  ListPostsQueryParams,
  ListPostsResponse,
  GetPostResponse,
  UpdatePostResponse,
  PublishPostResponse,
} from "@workspace/api-zod";
import * as Ayrshare from "../lib/ayrshare";

const router: IRouter = Router();

function sanitizePost(p: Record<string, unknown>) {
  return {
    ...p,
    accountId:     p["accountId"]     ?? undefined,
    contentId:     p["contentId"]     ?? undefined,
    mediaUrls:     Array.isArray(p["mediaUrls"]) ? p["mediaUrls"] : (p["mediaUrls"] == null ? [] : p["mediaUrls"]),
    ayrsharePostId: p["ayrsharePostId"] ?? undefined,
    errorMessage:  p["errorMessage"]  ?? undefined,
    publishedAt:   p["publishedAt"]   ?? undefined,
    scheduledAt:   p["scheduledAt"]   ?? undefined,
  };
}

router.get("/posts", async (req, res): Promise<void> => {
  const parsed = ListPostsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { status = "all" } = parsed.data;
  const posts = await db
    .select()
    .from(scheduledPostsTable)
    .orderBy(scheduledPostsTable.createdAt);

  const filtered = status === "all" ? posts : posts.filter((p) => p.status === status);
  const sanitized = filtered.map(sanitizePost);
  res.json(ListPostsResponse.parse(sanitized));
});

router.post("/posts", async (req, res): Promise<void> => {
  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const status = parsed.data.scheduledAt ? "scheduled" : "draft";
  const [post] = await db
    .insert(scheduledPostsTable)
    .values({ ...parsed.data, status })
    .returning();
  res.status(201).json(post);
});

router.get("/posts/:id", async (req, res): Promise<void> => {
  const params = GetPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [post] = await db
    .select()
    .from(scheduledPostsTable)
    .where(eq(scheduledPostsTable.id, params.data.id));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  res.json(GetPostResponse.parse(sanitizePost(post as unknown as Record<string, unknown>)));
});

router.patch("/posts/:id", async (req, res): Promise<void> => {
  const params = UpdatePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdatePostBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const updates: Record<string, unknown> = { ...body.data };
  if (body.data.scheduledAt && !body.data.status) {
    updates["status"] = "scheduled";
  }

  const [post] = await db
    .update(scheduledPostsTable)
    .set(updates)
    .where(eq(scheduledPostsTable.id, params.data.id))
    .returning();
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  res.json(UpdatePostResponse.parse(sanitizePost(post as unknown as Record<string, unknown>)));
});

router.delete("/posts/:id", async (req, res): Promise<void> => {
  const params = DeletePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(scheduledPostsTable)
    .where(eq(scheduledPostsTable.id, params.data.id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/posts/:id/publish", async (req, res): Promise<void> => {
  const params = PublishPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [post] = await db
    .select()
    .from(scheduledPostsTable)
    .where(eq(scheduledPostsTable.id, params.data.id));

  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const platforms = (post.platforms ?? []) as Ayrshare.Platform[];

  if (!Ayrshare.isConfigured()) {
    await db
      .update(scheduledPostsTable)
      .set({ status: "published", publishedAt: new Date() })
      .where(eq(scheduledPostsTable.id, params.data.id));

    for (const platform of platforms) {
      await db.insert(publishLogsTable).values({
        postId: post.id,
        platform,
        status: "success",
        ayrsharePostId: `mock_${Date.now()}`,
      });
    }

    res.json(PublishPostResponse.parse({
      success: true,
      message: "Post marked published (Ayrshare not configured — mock mode)",
      publishedAt: new Date(),
    }));
    return;
  }

  const mediaUrls = post.mediaUrls ?? [];
  const videoUrl = mediaUrls[0];

  if (!videoUrl) {
    res.status(400).json({ error: "Post has no media URL to publish" });
    return;
  }

  const result = await Ayrshare.publishToSocial({
    platforms,
    videoUrl,
    caption: post.caption ?? "",
    isVideo: true,
  });

  if (!result.success) {
    await db
      .update(scheduledPostsTable)
      .set({ status: "failed", errorMessage: result.errorMessage })
      .where(eq(scheduledPostsTable.id, params.data.id));

    for (const platform of platforms) {
      await db.insert(publishLogsTable).values({
        postId: post.id,
        platform,
        status: "failed",
        errorMessage: result.errorMessage,
      });
    }

    res.status(502).json(PublishPostResponse.parse({
      success: false,
      message: result.errorMessage ?? "Failed to publish via Ayrshare",
    }));
    return;
  }

  await db
    .update(scheduledPostsTable)
    .set({ status: "published", ayrsharePostId: result.postId, publishedAt: new Date() })
    .where(eq(scheduledPostsTable.id, params.data.id));

  for (const platform of platforms) {
    await db.insert(publishLogsTable).values({
      postId: post.id,
      platform,
      status: "success",
      ayrsharePostId: result.postId,
    });
  }

  res.json(PublishPostResponse.parse({
    success: true,
    ayrsharePostId: result.postId,
    message: result.scheduledAt ? `Scheduled for ${result.scheduledAt}` : "Published successfully",
    publishedAt: result.scheduledAt ? undefined : new Date(),
  }));
});

export default router;
