import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Users,
  TrendingUp,
  Image as ImageIcon,
  Calendar,
  Settings,
  Plus,
  Bot,
  Zap,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
} from "@/components/ui/sidebar";
import { useLang } from "@/contexts/LanguageContext";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { t, lang, setLang } = useLang();

  const navItems = [
    { href: "/", labelKey: "dashboard" as const, icon: LayoutDashboard },
    { href: "/accounts", labelKey: "accounts" as const, icon: Settings },
    { href: "/competitors", labelKey: "competitors" as const, icon: Users },
    { href: "/market-data", labelKey: "marketData" as const, icon: TrendingUp },
    { href: "/content", labelKey: "content" as const, icon: ImageIcon },
    { href: "/posts", labelKey: "posts" as const, icon: Calendar },
  ];

  const aiNavItem = { href: "/ai-autopilot", labelKey: "aiAutopilot" as const, icon: Bot };

  const currentLabel = [...navItems, aiNavItem].find((i) => i.href === location)?.labelKey;
  const pageTitle = currentLabel ? t.nav[currentLabel] : t.nav.dashboard;
  const isAiActive = location === aiNavItem.href;

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar className="border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-2 px-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold">
                S
              </div>
              <span className="text-xl font-bold tracking-tight">SocialAuto</span>
            </div>
          </SidebarHeader>
          <SidebarContent>
            {/* ── AI Autopilot hero entry ─────────────────── */}
            <div className="px-3 pt-1 pb-3">
              <Link href="/ai-autopilot">
                <div
                  className={cn(
                    "relative rounded-xl overflow-hidden cursor-pointer transition-all duration-200 group",
                    isAiActive
                      ? "ring-2 ring-indigo-500/60 shadow-lg shadow-indigo-500/20"
                      : "hover:shadow-md hover:shadow-indigo-500/10"
                  )}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 opacity-90" />
                  <div className="relative p-3 flex items-center gap-3">
                    <div className="h-9 w-9 rounded-lg bg-white/20 flex items-center justify-center shrink-0 backdrop-blur-sm">
                      <Bot className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-bold text-white leading-tight">
                          {t.nav.aiAutopilot}
                        </span>
                        <Sparkles className="h-3 w-3 text-yellow-300 animate-pulse shrink-0" />
                      </div>
                      <p className="text-[10px] text-white/70 leading-tight mt-0.5 truncate">
                        {lang === "zh" ? "一键全自动内容发布" : "One-click full automation"}
                      </p>
                    </div>
                    {!isAiActive && (
                      <div className="shrink-0">
                        <Zap className="h-4 w-4 text-yellow-300 animate-bounce" />
                      </div>
                    )}
                  </div>
                </div>
              </Link>
            </div>

            {/* ── Management nav ──────────────────────────── */}
            <SidebarGroup>
              <SidebarGroupLabel className="text-sidebar-foreground/50 uppercase text-[10px] font-bold tracking-wider px-6 py-2">
                {t.nav.management}
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => {
                    const isActive = location === item.href;
                    const label = t.nav[item.labelKey];
                    return (
                      <SidebarMenuItem key={item.href}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive}
                          tooltip={label}
                          className={cn(
                            "px-6 py-3 transition-colors",
                            isActive
                              ? "bg-sidebar-accent text-sidebar-accent-foreground"
                              : "hover:bg-sidebar-accent/50 text-sidebar-foreground/70 hover:text-sidebar-foreground"
                          )}
                        >
                          <Link href={item.href} className="flex items-center gap-3 w-full">
                            <item.icon
                              className={cn(
                                "h-5 w-5",
                                isActive ? "text-primary" : "text-sidebar-foreground/50"
                              )}
                            />
                            <span className="font-medium">{label}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="h-16 border-b border-border bg-card flex items-center justify-between px-8 sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="lg:hidden" />
              <h2 className="text-lg font-semibold">{pageTitle}</h2>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center rounded-lg border border-border overflow-hidden text-xs font-semibold">
                <button
                  onClick={() => setLang("zh")}
                  className={cn(
                    "px-3 py-1.5 transition-colors",
                    lang === "zh"
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted text-muted-foreground"
                  )}
                >
                  中文
                </button>
                <button
                  onClick={() => setLang("en")}
                  className={cn(
                    "px-3 py-1.5 transition-colors",
                    lang === "en"
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted text-muted-foreground"
                  )}
                >
                  EN
                </button>
              </div>
              <Link href="/posts">
                <Button variant="outline" size="sm" className="hidden sm:flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  {t.header.quickPost}
                </Button>
              </Link>
              <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center border border-border">
                <Users className="h-4 w-4" />
              </div>
            </div>
          </header>
          <div className="flex-1 overflow-auto p-8 bg-gray-50/50 dark:bg-background">
            <div className="max-w-7xl mx-auto space-y-8">{children}</div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
