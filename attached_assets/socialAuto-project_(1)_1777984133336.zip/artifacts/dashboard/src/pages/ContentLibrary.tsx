import { 
  useListContentItems, 
  useCreateContentItem, 
  useDeleteContentItem,
  useGenerateCaption,
  getListContentItemsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Plus, 
  Trash2, 
  Image as ImageIcon, 
  Video, 
  FileText,
  Sparkles,
  Search,
  PlusCircle,
  Copy,
  Check,
  RefreshCw,
  MoreVertical,
  Download
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useLang } from "@/contexts/LanguageContext";

export default function ContentLibraryPage() {
  const { t } = useLang();
  const { data: content, isLoading } = useListContentItems();
  const createContent = useCreateContentItem();
  const deleteContent = useDeleteContentItem();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);

  const handleDelete = (id: number) => {
    deleteContent.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListContentItemsQueryKey() });
        toast({ title: "Content deleted" });
      }
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t.content.title}</h1>
          <p className="text-muted-foreground mt-1">{t.content.subtitle}</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => setIsGeneratorOpen(true)}>
            <Sparkles className="h-4 w-4 mr-2 text-purple-600" />
            {t.content.aiCaption}
          </Button>
          <Button className="bg-primary" onClick={() => setIsCreateOpen(true)}>
            <PlusCircle className="h-4 w-4 mr-2" />
            {t.content.addContent}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {isLoading ? (
          Array(8).fill(0).map((_, i) => (
            <Card key={i} className="border-none shadow-sm overflow-hidden h-64">
              <Skeleton className="h-40 w-full" />
              <CardContent className="p-4 space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))
        ) : content?.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-white dark:bg-gray-900 rounded-xl border-2 border-dashed border-border">
            <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold">Library is empty</h3>
            <p className="text-muted-foreground">Upload your first image, video or text content.</p>
            <Button variant="outline" className="mt-4" onClick={() => setIsCreateOpen(true)}>
              Upload Content
            </Button>
          </div>
        ) : (
          content?.map((item) => (
            <Card key={item.id} className="group border-none shadow-sm hover:shadow-md transition-all overflow-hidden bg-white dark:bg-gray-900 flex flex-col">
              <div className="aspect-square w-full bg-muted relative group">
                {item.type === "image" && item.mediaUrl ? (
                  <img src={item.mediaUrl} alt={item.caption || "Content image"} className="object-cover w-full h-full" />
                ) : item.type === "video" ? (
                  <div className="w-full h-full flex items-center justify-center bg-slate-900">
                    <Video className="h-12 w-12 text-white/20" />
                  </div>
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-slate-50 p-6">
                    <FileText className="h-12 w-12 text-slate-200" />
                  </div>
                )}
                
                <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="secondary" size="icon" className="h-8 w-8 bg-white/90 backdrop-blur-sm">
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="destructive" 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => handleDelete(item.id)}
                    disabled={deleteContent.isPending}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="absolute bottom-2 left-2">
                  <Badge className={cn(
                    "border-none backdrop-blur-md",
                    item.type === "image" ? "bg-blue-500/80 text-white" : 
                    item.type === "video" ? "bg-pink-500/80 text-white" : "bg-slate-500/80 text-white"
                  )}>
                    {item.type}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-3">
                <h4 className="font-medium text-sm truncate">{item.caption || "Untitled Content"}</h4>
                {item.industry && (
                  <p className="text-xs text-muted-foreground line-clamp-1 mt-1">{item.industry}</p>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Content</DialogTitle>
          </DialogHeader>
          <AddContentForm onComplete={() => {
            setIsCreateOpen(false);
            queryClient.invalidateQueries({ queryKey: getListContentItemsQueryKey() });
          }} />
        </DialogContent>
      </Dialog>

      <Dialog open={isGeneratorOpen} onOpenChange={setIsGeneratorOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-purple-600" /> AI Caption Generator
            </DialogTitle>
          </DialogHeader>
          <AICaptionGenerator />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function AddContentForm({ onComplete }: { onComplete: () => void }) {
  const createContent = useCreateContentItem();
  const { toast } = useToast();
  
  const form = useForm({
    defaultValues: {
      type: "image" as any,
      caption: "",
      mediaUrl: "",
      industry: "",
    }
  });

  const onSubmit = (data: any) => {
    createContent.mutate({ data }, {
      onSuccess: () => {
        toast({ title: "Content added successfully" });
        onComplete();
      }
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Content Type</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="image">Image</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                  <SelectItem value="text">Text / Copy</SelectItem>
                </SelectContent>
              </Select>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="caption"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Caption / Title</FormLabel>
              <FormControl>
                <Input placeholder="Summer Promotion 2024" {...field} />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="mediaUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Media URL</FormLabel>
              <FormControl>
                <Input placeholder="https://example.com/image.jpg" {...field} />
              </FormControl>
              <FormDescription>Link to your image or video file.</FormDescription>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="industry"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Industry (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="e.g. Beauty" {...field} />
              </FormControl>
            </FormItem>
          )}
        />
        <DialogFooter className="pt-4">
          <Button type="submit" disabled={createContent.isPending}>
            {createContent.isPending ? "Adding..." : "Add to Library"}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

function AICaptionGenerator() {
  const [topic, setTopic] = useState("");
  const [tone, setTone] = useState("casual");
  const generate = useGenerateCaption();
  const { toast } = useToast();
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleGenerate = () => {
    if (!topic) return;
    generate.mutate({ data: { product: topic, industry: "general", tone: tone as any } });
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    toast({ title: "Copied to clipboard" });
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-6 pt-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">What is your post about?</label>
          <Textarea 
            placeholder="e.g. New summer skincare collection launching this weekend with 20% off..." 
            className="min-h-[100px]"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
          />
        </div>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Tone of Voice</label>
            <Select value={tone} onValueChange={setTone}>
              <SelectTrigger>
                <SelectValue placeholder="Select tone" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="casual">Casual & Fun</SelectItem>
                <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                <SelectItem value="minimalist">Minimalist</SelectItem>
                <SelectItem value="educational">Educational</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button 
            className="w-full h-12 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 border-none" 
            onClick={handleGenerate}
            disabled={generate.isPending || !topic}
          >
            {generate.isPending ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="h-4 w-4 mr-2" />
            )}
            Generate Captions
          </Button>
        </div>
      </div>

      {generate.data?.captions && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
          <h4 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Generated Options</h4>
          <div className="grid gap-3">
            {generate.data.captions.map((caption, i) => (
              <div key={i} className="group relative bg-muted/30 rounded-xl p-4 border border-border/50 hover:bg-muted/50 transition-colors">
                <p className="text-sm leading-relaxed pr-10">{caption}</p>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="absolute top-2 right-2 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => copyToClipboard(caption, i)}
                >
                  {copiedIndex === i ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

import { cn } from "@/lib/utils";
