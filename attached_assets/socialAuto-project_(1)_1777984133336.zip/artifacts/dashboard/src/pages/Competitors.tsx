import { 
  useListCompetitors, 
  useCreateCompetitor, 
  useDeleteCompetitor,
  useListCompetitorPosts,
  getListCompetitorsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Plus, 
  Trash2, 
  Users, 
  ExternalLink,
  ChevronRight,
  PlusCircle,
  Eye,
  ArrowLeft,
  Calendar,
  MessageSquare,
  Heart
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useState } from "react";
import { format } from "date-fns";
import { useLang } from "@/contexts/LanguageContext";

export default function CompetitorsPage() {
  const { t } = useLang();
  const { data: competitors, isLoading } = useListCompetitors();
  const createCompetitor = useCreateCompetitor();
  const deleteCompetitor = useDeleteCompetitor();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedCompetitor, setSelectedCompetitor] = useState<any>(null);

  const form = useForm({
    defaultValues: {
      platform: "facebook" as any,
      name: "",
      pageUrl: "",
    }
  });

  const onSubmit = (data: any) => {
    createCompetitor.mutate({ data }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCompetitorsQueryKey() });
        toast({ title: "Competitor added", description: "You are now monitoring this competitor." });
        setIsCreateOpen(false);
        form.reset();
      }
    });
  };

  const handleDelete = (id: number) => {
    deleteCompetitor.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCompetitorsQueryKey() });
        toast({ title: "Competitor removed" });
        if (selectedCompetitor?.id === id) setSelectedCompetitor(null);
      }
    });
  };

  if (selectedCompetitor) {
    return (
      <CompetitorDetail 
        competitor={selectedCompetitor} 
        onBack={() => setSelectedCompetitor(null)} 
      />
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t.competitors.title}</h1>
          <p className="text-muted-foreground mt-1">{t.competitors.subtitle}</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <PlusCircle className="h-4 w-4 mr-2" />
              Add Competitor
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Monitor New Competitor</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="platform"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Platform</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select platform" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="facebook">Facebook</SelectItem>
                          <SelectItem value="tiktok">TikTok</SelectItem>
                          <SelectItem value="instagram">Instagram</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Competitor Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Rival Beauty Bar" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pageUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Page URL</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. https://facebook.com/rival" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter className="pt-4">
                  <Button type="submit" disabled={createCompetitor.isPending}>
                    {createCompetitor.isPending ? "Adding..." : "Add Competitor"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <Card key={i} className="border-none shadow-sm">
              <CardHeader className="flex flex-row items-center gap-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-20" />
                </div>
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))
        ) : competitors?.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-white dark:bg-gray-900 rounded-xl border-2 border-dashed border-border">
            <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold">No competitors monitored</h3>
            <p className="text-muted-foreground">Add your first competitor to start tracking their content.</p>
            <Button variant="outline" className="mt-4" onClick={() => setIsCreateOpen(true)}>
              Add Competitor
            </Button>
          </div>
        ) : (
          competitors?.map((competitor) => (
            <Card key={competitor.id} className="group border-none shadow-sm hover:shadow-md transition-all bg-white dark:bg-gray-900 overflow-hidden cursor-pointer" onClick={() => setSelectedCompetitor(competitor)}>
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-accent flex items-center justify-center text-accent-foreground font-bold">
                      {competitor.name.charAt(0)}
                    </div>
                    <div>
                      <CardTitle className="text-base">{competitor.name}</CardTitle>
                      <CardDescription className="text-xs">{competitor.platform} · {competitor.pageId || competitor.pageUrl}</CardDescription>
                    </div>
                  </div>
                  <Badge variant="outline" className="capitalize">
                    {competitor.platform}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mt-4">
                  <Button variant="ghost" size="sm" className="text-xs group-hover:text-primary transition-colors p-0">
                    <Eye className="h-3 w-3 mr-2" /> View Analysis
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-destructive hover:bg-destructive/10 h-8 w-8 p-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(competitor.id);
                    }}
                    disabled={deleteCompetitor.isPending}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}

function CompetitorDetail({ competitor, onBack }: { competitor: any, onBack: () => void }) {
  const { data: posts, isLoading } = useListCompetitorPosts(competitor.id);

  return (
    <div className="space-y-8 animate-in slide-in-from-right duration-500">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{competitor.name}</h1>
          <p className="text-muted-foreground mt-1">Analyzing content from {competitor.platform}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array(6).fill(0).map((_, i) => (
            <Card key={i} className="border-none shadow-sm h-64">
              <CardContent className="p-4 space-y-4">
                <Skeleton className="h-32 w-full rounded-lg" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))
        ) : posts?.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-white dark:bg-gray-900 rounded-xl border border-border">
            <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold">No posts found</h3>
            <p className="text-muted-foreground">We haven't indexed any posts for this competitor yet.</p>
          </div>
        ) : (
          posts?.map((post) => (
            <Card key={post.id} className="border-none shadow-sm hover:shadow-md transition-all overflow-hidden bg-white dark:bg-gray-900">
              {post.mediaUrls && post.mediaUrls.length > 0 && (
                <div className="aspect-video w-full bg-muted relative">
                  <img src={post.mediaUrls[0]} alt="Post content" className="object-cover w-full h-full" />
                </div>
              )}
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {post.publishedAt ? format(new Date(post.publishedAt), "MMM d, yyyy") : "Unknown"}
                  </span>
                </div>
                <p className="text-sm line-clamp-3">{post.caption}</p>
                <div className="flex items-center gap-4 pt-2 border-t border-border/50">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Heart className="h-3 w-3 text-pink-500" />
                    {post.likes || 0}
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <MessageSquare className="h-3 w-3 text-blue-500" />
                    {post.comments || 0}
                  </div>
                  {post.postUrl && (
                    <a 
                      href={post.postUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="ml-auto text-xs text-primary hover:underline flex items-center gap-1"
                    >
                      View <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}

import { cn } from "@/lib/utils";
