import {
  useListAccounts,
  useCreateAccount,
  useDeleteAccount,
  getListAccountsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Trash2,
  Facebook,
  Video,
  CheckCircle2,
  ExternalLink,
  PlusCircle,
  Settings,
  Instagram,
  Info,
  Loader2,
  ShieldCheck,
  RefreshCw,
  Link2,
  XCircle,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useState } from "react";
import { useLang } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const DEFAULT_CUSTOMER_ID = "default";

function platformProfileUrl(platform: string, accountId: string): string {
  if (platform === "facebook") return `https://facebook.com/${accountId}`;
  if (platform === "instagram") return `https://instagram.com/${accountId}`;
  if (platform === "tiktok") return `https://tiktok.com/@${accountId}`;
  return "#";
}

interface AyrshareDisplayName {
  platform: string;
  displayName: string;
  username: string;
  userImage?: string;
}

interface AyrshareStatus {
  configured: boolean;
  facebookLinked: boolean;
  instagramLinked: boolean;
  tiktokLinked: boolean;
  platforms: string[];
  displayNames: AyrshareDisplayName[];
  dashboardUrl: string;
}

function useAyrshareStatus() {
  return useQuery<AyrshareStatus>({
    queryKey: ["ayrshare-status"],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/social-accounts/ayrshare/status`);
      if (!res.ok) throw new Error("Failed to fetch Ayrshare status");
      return res.json();
    },
    staleTime: 30_000,
  });
}

function useSyncAyrshare() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(`${BASE}/api/social-accounts/ayrshare/sync`, { method: "POST" });
      if (!res.ok) throw new Error("Sync failed");
      return res.json() as Promise<{ synced: number; accounts: string[] }>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["ayrshare-status"] });
      queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() });
    },
  });
}

export default function AccountsPage() {
  const { t } = useLang();
  const { data: accounts, isLoading } = useListAccounts();
  const deleteAccount = useDeleteAccount();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isManualOpen, setIsManualOpen] = useState(false);
  const [isConnectOpen, setIsConnectOpen] = useState(false);

  const { data: ayrshareStatus, isLoading: ayrshareLoading } = useAyrshareStatus();
  const syncAyrshare = useSyncAyrshare();

  const handleFbConnect = () => {
    setIsConnectOpen(false);
    window.location.href = `${BASE}/api/oauth/facebook/connect?customerId=${DEFAULT_CUSTOMER_ID}`;
  };

  const handleTikTokConnect = () => {
    setIsConnectOpen(false);
    window.location.href = `${BASE}/api/oauth/tiktok/connect?customerId=${DEFAULT_CUSTOMER_ID}`;
  };

  const handleDelete = (id: number) => {
    deleteAccount.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() });
        toast({ title: t.lang === "zh" ? "已移除账号" : "Account removed" });
      }
    });
  };

  const handleSync = () => {
    syncAyrshare.mutate(undefined, {
      onSuccess: (data) => {
        toast({
          title: t.lang === "zh" ? `同步完成：${data.synced} 个账号` : `Synced ${data.synced} accounts`,
        });
      },
      onError: () => {
        toast({
          title: t.lang === "zh" ? "同步失败" : "Sync failed",
          variant: "destructive",
        });
      },
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t.accounts.title}</h1>
          <p className="text-muted-foreground mt-1">{t.accounts.subtitle}</p>
        </div>
        <Dialog open={isConnectOpen} onOpenChange={setIsConnectOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <PlusCircle className="h-4 w-4 mr-2" />
              {t.accounts.connectNew}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{t.accounts.connectNew}</DialogTitle>
              <DialogDescription>{t.accounts.howToConnect}</DialogDescription>
            </DialogHeader>

            <div className="space-y-4 pt-2">
              {/* Facebook + Instagram OAuth */}
              <div className="rounded-xl border border-blue-200 bg-blue-50 dark:bg-blue-950/30 dark:border-blue-800 p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-blue-600 flex items-center justify-center shrink-0">
                    <Facebook className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm">Facebook + Instagram</h4>
                    <p className="text-xs text-muted-foreground">
                      {t.lang === "zh"
                        ? "使用 Meta OAuth 2.0 授权，自动获取 60 天长效 Token"
                        : "Meta OAuth 2.0 — auto-fetches 60-day long-lived token"}
                    </p>
                  </div>
                </div>
                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={handleFbConnect}
                >
                  <ShieldCheck className="h-4 w-4 mr-2" />
                  {t.accounts.connectFacebook}
                </Button>
              </div>

              {/* TikTok native OAuth */}
              <div className="rounded-xl border border-gray-200 bg-gray-50 dark:bg-gray-900/50 dark:border-gray-800 p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-black flex items-center justify-center shrink-0">
                    <Video className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm">TikTok</h4>
                    <p className="text-xs text-muted-foreground">
                      {t.lang === "zh"
                        ? "TikTok 官方 OAuth 授权，直发或草稿箱降级"
                        : "TikTok Login Kit — direct post or inbox fallback"}
                    </p>
                  </div>
                </div>
                <Button
                  className="w-full"
                  variant="outline"
                  onClick={handleTikTokConnect}
                >
                  <Video className="h-4 w-4 mr-2" />
                  {t.accounts.connectTikTok}
                </Button>
              </div>

              {/* Ayrshare (all three platforms) */}
              <div className="rounded-xl border border-purple-200 bg-purple-50 dark:bg-purple-950/30 dark:border-purple-800 p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-purple-600 flex items-center justify-center shrink-0">
                    <Link2 className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm">
                      {t.lang === "zh" ? "Ayrshare（三平台统一授权）" : "Ayrshare (all platforms)"}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      {t.lang === "zh"
                        ? "一次授权，同时管理 FB / IG / TikTok 发布"
                        : "One authorization for FB / IG / TikTok publishing"}
                    </p>
                  </div>
                </div>
                <Button
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={() => {
                    setIsConnectOpen(false);
                    window.open("https://app.ayrshare.com/social-accounts", "_blank");
                  }}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  {t.lang === "zh" ? "前往 Ayrshare 授权" : "Open Ayrshare Dashboard"}
                </Button>
              </div>

              <div className="border-t border-border pt-4">
                <button
                  className="text-xs text-muted-foreground underline underline-offset-2 hover:text-foreground transition-colors"
                  onClick={() => {
                    setIsConnectOpen(false);
                    setIsManualOpen(true);
                  }}
                >
                  {t.lang === "zh" ? "手动输入账号信息 →" : "Enter account details manually →"}
                </button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Ayrshare status panel */}
      <AyrshareStatusPanel
        status={ayrshareStatus}
        isLoading={ayrshareLoading}
        isSyncing={syncAyrshare.isPending}
        onSync={handleSync}
        lang={t.lang}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <Card key={i} className="border-none shadow-sm">
              <CardHeader className="flex flex-row items-center gap-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-20" />
                </div>
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-full" />
              </CardContent>
            </Card>
          ))
        ) : accounts?.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-white dark:bg-gray-900 rounded-xl border-2 border-dashed border-border">
            <Settings className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold">{t.accounts.noAccounts}</h3>
            <p className="text-muted-foreground">{t.accounts.noAccountsDesc}</p>
            <Button variant="outline" className="mt-4" onClick={() => setIsConnectOpen(true)}>
              {t.accounts.getStarted}
            </Button>
          </div>
        ) : (
          accounts?.map((account) => (
            <Card key={account.id} className="group relative border-none shadow-sm hover:shadow-md transition-all bg-white dark:bg-gray-900 overflow-hidden">
              <div className={cn(
                "absolute top-0 left-0 w-1 h-full",
                account.platform === "facebook" ? "bg-blue-600" :
                account.platform === "tiktok" ? "bg-black" : "bg-gradient-to-b from-pink-500 to-purple-600"
              )} />
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "h-10 w-10 rounded-lg flex items-center justify-center",
                      account.platform === "facebook" ? "bg-blue-50 text-blue-600" :
                      account.platform === "tiktok" ? "bg-gray-100 text-black" :
                      "bg-pink-50 text-pink-600"
                    )}>
                      {account.platform === "facebook" ? <Facebook className="h-5 w-5" /> :
                       account.platform === "instagram" ? <Instagram className="h-5 w-5" /> :
                       <Video className="h-5 w-5" />}
                    </div>
                    <div>
                      <CardTitle className="text-base">{account.accountName}</CardTitle>
                      <CardDescription className="text-xs capitalize">
                        {account.platform} · {account.accountId}
                      </CardDescription>
                    </div>
                  </div>
                  <Badge variant="secondary" className="bg-green-50 text-green-700 hover:bg-green-50 border-green-100">
                    <CheckCircle2 className="h-3 w-3 mr-1" /> {t.accounts.connected}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between gap-2 mt-2">
                  <Button variant="outline" size="sm" className="flex-1 text-xs" asChild>
                    <a
                      href={platformProfileUrl(account.platform, account.accountId)}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <ExternalLink className="h-3 w-3 mr-2" /> {t.accounts.viewProfile}
                    </a>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => handleDelete(account.id)}
                    disabled={deleteAccount.isPending}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                {account.tokenExpiresAt && (
                  <p className="text-xs text-muted-foreground mt-2">
                    {t.lang === "zh" ? "Token 到期：" : "Token expires: "}
                    {new Date(account.tokenExpiresAt).toLocaleDateString()}
                  </p>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Manual entry dialog */}
      <ManualAccountDialog
        open={isManualOpen}
        onOpenChange={setIsManualOpen}
        onSuccess={() => {
          setIsManualOpen(false);
          queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() });
        }}
      />
    </div>
  );
}

function AyrshareStatusPanel({
  status,
  isLoading,
  isSyncing,
  onSync,
  lang,
}: {
  status?: AyrshareStatus;
  isLoading: boolean;
  isSyncing: boolean;
  onSync: () => void;
  lang: string;
}) {
  const isZh = lang === "zh";

  if (isLoading) {
    return (
      <Card className="border-none shadow-sm bg-white dark:bg-gray-900">
        <CardContent className="pt-6">
          <Skeleton className="h-24 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!status) return null;

  const platforms = [
    { key: "facebookLinked", label: "Facebook", icon: <Facebook className="h-4 w-4" />, color: "text-blue-600" },
    { key: "instagramLinked", label: "Instagram", icon: <Instagram className="h-4 w-4" />, color: "text-pink-600" },
    { key: "tiktokLinked", label: "TikTok", icon: <Video className="h-4 w-4" />, color: "text-gray-800" },
  ] as const;

  return (
    <Card className="border-none shadow-sm bg-white dark:bg-gray-900">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-purple-100 dark:bg-purple-900/40 flex items-center justify-center">
              <Link2 className="h-4 w-4 text-purple-600" />
            </div>
            <div>
              <CardTitle className="text-base">
                {isZh ? "Ayrshare 发布授权" : "Ayrshare Publish Authorization"}
              </CardTitle>
              <CardDescription className="text-xs">
                {isZh
                  ? "通过 Ayrshare 统一管理三平台发布权限"
                  : "Unified publish authorization for FB / IG / TikTok"}
              </CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {status.configured && (
              <Button
                variant="outline"
                size="sm"
                onClick={onSync}
                disabled={isSyncing}
                className="text-xs"
              >
                {isSyncing
                  ? <Loader2 className="h-3 w-3 animate-spin mr-1" />
                  : <RefreshCw className="h-3 w-3 mr-1" />}
                {isZh ? "同步账号" : "Sync Accounts"}
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              className="text-xs"
              onClick={() => window.open(status.dashboardUrl, "_blank")}
            >
              <ExternalLink className="h-3 w-3 mr-1" />
              {isZh ? "Ayrshare 后台" : "Dashboard"}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {!status.configured ? (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription className="text-xs">
              {isZh
                ? "未配置 AYRSHARE_API_KEY。请在 Secrets 中添加该变量以启用三平台统一发布。"
                : "AYRSHARE_API_KEY is not set. Add it to Secrets to enable multi-platform publishing."}
            </AlertDescription>
          </Alert>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            {platforms.map(({ key, label, icon, color }) => {
              const linked = status[key];
              const info = status.displayNames.find((d) => d.platform === label.toLowerCase());
              return (
                <div
                  key={key}
                  className={cn(
                    "flex items-center gap-2 rounded-lg px-3 py-2 border",
                    linked
                      ? "border-green-200 bg-green-50 dark:bg-green-950/20 dark:border-green-800"
                      : "border-border bg-muted/30"
                  )}
                >
                  <span className={cn(linked ? color : "text-muted-foreground")}>{icon}</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium truncate">{label}</p>
                    {linked && info ? (
                      <p className="text-[11px] text-muted-foreground truncate">{info.displayName || info.username}</p>
                    ) : (
                      <p className="text-[11px] text-muted-foreground">
                        {linked
                          ? (isZh ? "已连接" : "Connected")
                          : (isZh ? "未授权" : "Not linked")}
                      </p>
                    )}
                  </div>
                  {linked
                    ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" />
                    : <XCircle className="h-3.5 w-3.5 text-muted-foreground shrink-0" />}
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ManualAccountDialog({
  open,
  onOpenChange,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSuccess: () => void;
}) {
  const { t } = useLang();
  const createAccount = useCreateAccount();
  const { toast } = useToast();

  const form = useForm({
    defaultValues: {
      platform: "facebook" as "facebook" | "tiktok" | "instagram",
      accountId: "",
      accountName: "",
    }
  });

  const onSubmit = (data: { platform: "facebook" | "tiktok" | "instagram"; accountId: string; accountName: string }) => {
    createAccount.mutate({ data }, {
      onSuccess: () => {
        toast({ title: t.accounts.connected });
        onSuccess();
        form.reset();
      },
      onError: () => {
        toast({
          title: t.lang === "zh" ? "连接失败" : "Connection failed",
          description: t.lang === "zh" ? "连接账号时发生错误，请重试。" : "There was an error connecting your account.",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{t.accounts.connect}</DialogTitle>
        </DialogHeader>
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription className="text-xs">
            {t.lang === "zh"
              ? "手动添加账号不含 Token，仅作为记录使用。建议使用上方 OAuth 按钮授权。"
              : "Manually added accounts don't include tokens. Use the OAuth buttons above for full access."}
          </AlertDescription>
        </Alert>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-2">
            <FormField
              control={form.control}
              name="platform"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.lang === "zh" ? "平台" : "Platform"}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder={t.lang === "zh" ? "选择平台" : "Select platform"} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="facebook">Facebook</SelectItem>
                      <SelectItem value="tiktok">TikTok</SelectItem>
                      <SelectItem value="instagram">Instagram</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="accountName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.lang === "zh" ? "账号名称" : "Account Name"}</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. My Beauty Salon" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="accountId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.lang === "zh" ? "账号 ID / 用户名" : "Account ID / Username"}</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. 123456789 or @mypage" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="pt-4">
              <Button type="submit" disabled={createAccount.isPending}>
                {createAccount.isPending
                  ? (t.lang === "zh" ? "连接中…" : "Connecting…")
                  : t.accounts.connect}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
