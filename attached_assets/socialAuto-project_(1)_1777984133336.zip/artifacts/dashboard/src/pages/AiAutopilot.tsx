import { useState, useEffect, useRef } from "react";
import { useLang } from "@/contexts/LanguageContext";
import {
  useListCompetitors,
  useListContentItems,
  useGetAnalyticsSummary,
  useListAccounts,
  useGetTrendingContent,
} from "@workspace/api-client-react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bot, Zap, ShieldCheck, Search, TrendingUp, Sparkles, Calendar, Send,
  CheckCircle2, ChevronRight, Play, RotateCcw, Clock, Users,
  Image as ImageIcon, RefreshCw, Facebook, Video, Instagram,
  AlertCircle, ArrowRight, Eye, Heart, MessageCircle,
  Settings, KeyRound, Upload, FileVideo, FileImage, X, UploadCloud, Mic2,
} from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type StepState = "pending" | "running" | "done";

interface Step {
  id: number;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderColor: string;
}

const STEPS: Step[] = [
  { id: 0, icon: KeyRound,  color: "text-cyan-400",   bgColor: "bg-cyan-500/10",   borderColor: "border-cyan-500/30" },
  { id: 1, icon: Search,    color: "text-blue-400",   bgColor: "bg-blue-500/10",   borderColor: "border-blue-500/30" },
  { id: 2, icon: Sparkles,  color: "text-yellow-400", bgColor: "bg-yellow-500/10", borderColor: "border-yellow-500/30" },
  { id: 3, icon: Calendar,  color: "text-green-400",  bgColor: "bg-green-500/10",  borderColor: "border-green-500/30" },
  { id: 4, icon: Send,      color: "text-pink-400",   bgColor: "bg-pink-500/10",   borderColor: "border-pink-500/30" },
];

const STEP_DURATIONS = [2500, 2500, 3500, 2000, 2000];

const UPLOAD_STEPS: Step[] = [
  { id: 0, icon: KeyRound,   color: "text-cyan-400",   bgColor: "bg-cyan-500/10",   borderColor: "border-cyan-500/30" },
  { id: 1, icon: UploadCloud, color: "text-violet-400", bgColor: "bg-violet-500/10", borderColor: "border-violet-500/30" },
  { id: 2, icon: Calendar,   color: "text-green-400",  bgColor: "bg-green-500/10",  borderColor: "border-green-500/30" },
  { id: 3, icon: Send,       color: "text-pink-400",   bgColor: "bg-pink-500/10",   borderColor: "border-pink-500/30" },
];
const UPLOAD_STEP_DURATIONS = [2000, 2500, 2000, 2500];

type LogEntry = { id: number; text: string; ts: string };

function useTypewriter(text: string, speed = 30, active = false) {
  const [displayed, setDisplayed] = useState("");
  useEffect(() => {
    if (!active) { setDisplayed(""); return; }
    let i = 0;
    setDisplayed("");
    const iv = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) clearInterval(iv);
    }, speed);
    return () => clearInterval(iv);
  }, [text, active]);
  return displayed;
}

function LogPanel({ logs }: { logs: LogEntry[] }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [logs]);
  return (
    <div ref={ref} className="h-52 overflow-y-auto font-mono text-xs space-y-1 p-3 bg-black/60 rounded-xl border border-white/10">
      {logs.length === 0 && <span className="text-white/30">{">"} Awaiting AI initialization...</span>}
      {logs.map((l) => (
        <div key={l.id} className="flex gap-2 animate-in fade-in slide-in-from-bottom-1 duration-300">
          <span className="text-white/30 shrink-0">{l.ts}</span>
          <span className="text-green-400">{l.text}</span>
        </div>
      ))}
    </div>
  );
}

function StepCard({ step, state, title, desc, progress }: {
  step: Step; state: StepState; title: string; desc: string; progress: number;
}) {
  const Icon = step.icon;
  return (
    <div className={cn(
      "relative rounded-2xl border p-5 transition-all duration-500",
      state === "running" ? `${step.bgColor} ${step.borderColor} shadow-lg scale-[1.02]`
        : state === "done" ? "bg-white/5 border-white/20"
        : "bg-white/3 border-white/10 opacity-50"
    )}>
      {state === "running" && (
        <div className="absolute inset-0 rounded-2xl overflow-hidden pointer-events-none">
          <div className="absolute inset-0 opacity-20 animate-pulse"
            style={{ background: `radial-gradient(ellipse at 50% 0%, ${step.color.replace("text-", "").replace("-400", "")} 0%, transparent 70%)` }} />
        </div>
      )}
      <div className="relative flex items-start gap-4">
        <div className={cn(
          "h-10 w-10 rounded-xl flex items-center justify-center shrink-0 transition-all",
          state === "done" ? "bg-green-500/20 border border-green-500/30" : `${step.bgColor} border ${step.borderColor}`
        )}>
          {state === "done" ? <CheckCircle2 className="h-5 w-5 text-green-400" />
            : state === "running" ? <Icon className={cn("h-5 w-5 animate-pulse", step.color)} />
            : <Icon className="h-5 w-5 text-white/30" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h3 className={cn("font-semibold text-sm", state === "pending" ? "text-white/40" : "text-white")}>{title}</h3>
            {state === "running" && <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 text-[10px] px-2 py-0 shrink-0 animate-pulse">运行中</Badge>}
            {state === "done" && <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-[10px] px-2 py-0 shrink-0">完成</Badge>}
          </div>
          <p className={cn("text-xs mt-0.5", state === "pending" ? "text-white/25" : "text-white/50")}>{desc}</p>
          {state === "running" && <div className="mt-3"><Progress value={progress} className="h-1 bg-white/10" /></div>}
        </div>
      </div>
    </div>
  );
}

function GeneratedContentPreview({ active, lang }: { active: boolean; lang: "en" | "zh" }) {
  const captions = lang === "zh"
    ? [
        "✨ 夏日美肌特惠！现在预约护肤套餐享 8 折优惠，名额有限，先到先得 💆‍♀️ #美容沙龙 #夏日特惠",
        "🌟 NEW ARRIVAL | 我们的明星产品回来了！你最爱的胶原蛋白面膜已全面上架，点击主页链接立即抢购 →",
        "今日特供 ☕ 双人套餐第二份半价！周末限定，带上你的闺蜜来打卡吧～ 📸",
      ]
    : [
        "✨ Summer Glow Special! Book your skincare package now and save 20% — limited slots available 💆‍♀️",
        "🌟 NEW ARRIVAL | Our best-selling collagen mask is back in stock! Click the link in bio to shop now →",
        "Today only ☕ Buy 1 Get 1 Half Price on all duo packages! Tag a friend 📸",
      ];

  const [idx, setIdx] = useState(0);
  const caption = useTypewriter(captions[idx], 25, active);

  useEffect(() => {
    if (!active) { setIdx(0); return; }
    const iv = setInterval(() => setIdx((i) => (i + 1) % captions.length), 4000);
    return () => clearInterval(iv);
  }, [active]);

  if (!active) return null;
  return (
    <div className="mt-3 rounded-xl bg-black/40 border border-white/10 p-3 text-xs text-white/80 leading-relaxed font-light min-h-[60px] animate-in fade-in">
      <span className="text-yellow-400 mr-2">✦</span>
      {caption}
      <span className="inline-block w-0.5 h-3.5 bg-yellow-400 ml-0.5 animate-pulse align-text-bottom" />
    </div>
  );
}

// ── Auto-mode Step Results ────────────────────────────────────────────
type AccountItem = { id: string; platform: string; accountName: string };
type CompetitorItem = { id: string; name: string; platform?: string };

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).catch(() => {});
}

function ResultCard({ title, icon: Icon, iconColor, children, warning }: {
  title: string; icon: React.ElementType; iconColor: string; children: React.ReactNode; warning?: boolean;
}) {
  return (
    <div className={cn(
      "rounded-2xl border p-4 space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-400",
      warning ? "bg-amber-500/5 border-amber-500/25" : "bg-white/5 border-white/10",
    )}>
      <div className="flex items-center gap-2">
        <Icon className={cn("h-4 w-4", iconColor)} />
        <p className="text-xs font-semibold text-white/70 uppercase tracking-wider">{title}</p>
      </div>
      {children}
    </div>
  );
}

function AuthResult({ isZh, accounts, ayrshareConfigured }: {
  isZh: boolean; accounts: AccountItem[]; ayrshareConfigured: boolean;
}) {
  const fbAccounts = accounts.filter((a) => a.platform?.toLowerCase().includes("facebook"));
  const igAccounts = accounts.filter((a) => a.platform?.toLowerCase().includes("instagram"));
  const hasAnyAccount = accounts.length > 0;
  const hasWarning = !hasAnyAccount || !ayrshareConfigured;

  const platforms = [
    {
      name: "Facebook", icon: Facebook,
      ok: fbAccounts.length > 0,
      hint: fbAccounts.length > 0 ? (isZh ? `${fbAccounts.length} 个账号已授权` : `${fbAccounts.length} account(s) connected`) : (isZh ? "未连接" : "Not connected"),
    },
    {
      name: "Instagram", icon: Instagram,
      ok: igAccounts.length > 0,
      hint: igAccounts.length > 0 ? (isZh ? `${igAccounts.length} 个账号已授权` : `${igAccounts.length} account(s) connected`) : (isZh ? "未连接" : "Not connected"),
    },
    {
      name: "TikTok (Ayrshare)", icon: Video,
      ok: ayrshareConfigured,
      hint: ayrshareConfigured ? (isZh ? "API Key 已配置" : "API Key configured") : (isZh ? "未配置 Ayrshare API Key" : "Ayrshare API Key not set"),
    },
  ];

  return (
    <ResultCard
      title={isZh ? "账号授权状态" : "Account Authorization"}
      icon={KeyRound}
      iconColor="text-cyan-400"
      warning={hasWarning}
    >
      <div className="space-y-2">
        {platforms.map(({ name, icon: Icon, ok, hint }) => (
          <div key={name} className={cn(
            "flex items-center gap-3 rounded-xl px-3 py-2 border",
            ok ? "bg-green-500/10 border-green-500/20" : "bg-amber-500/10 border-amber-500/20",
          )}>
            <Icon className={cn("h-4 w-4 shrink-0", ok ? "text-green-400" : "text-amber-400")} />
            <div className="flex-1 min-w-0">
              <p className={cn("text-xs font-medium", ok ? "text-green-300" : "text-amber-300")}>{name}</p>
              <p className="text-[11px] text-white/40">{hint}</p>
            </div>
            {ok ? <CheckCircle2 className="h-4 w-4 text-green-400 shrink-0" /> : <AlertCircle className="h-4 w-4 text-amber-400 shrink-0" />}
          </div>
        ))}
      </div>
      {hasWarning && (
        <div className="rounded-xl bg-amber-500/10 border border-amber-500/20 px-3 py-2.5 flex items-start gap-2.5">
          <AlertCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-amber-300 font-medium">
              {isZh ? "⚠ 部分平台未授权，发布功能受限" : "⚠ Some platforms not authorized — publishing may be limited"}
            </p>
            <Link href="/accounts">
              <span className="inline-flex items-center gap-1 mt-1.5 text-[11px] text-cyan-400 hover:text-cyan-300 cursor-pointer font-medium">
                {isZh ? "前往社交账号页面授权" : "Go to Social Accounts to authorize"}
                <ArrowRight className="h-3 w-3" />
              </span>
            </Link>
          </div>
        </div>
      )}
    </ResultCard>
  );
}

function AnalyzeResult({ isZh, competitors }: {
  isZh: boolean;
  competitors: CompetitorItem[];
}) {
  const hasCompetitors = competitors.length > 0;
  const { data: trending, isLoading: trendingLoading } = useGetTrendingContent({ industry: "beauty" });

  const insights = isZh
    ? ["周末护肤套餐互动率最高，建议重点排程", "美甲短视频涨粉速度最快（+23%/周）", "带 #促销优惠 话题标签曝光提升 40%"]
    : ["Weekend skincare bundles drive highest engagement", "Nail short-videos grow followers fastest (+23%/wk)", "Posts with #sale hashtag reach 40% more audience"];

  return (
    <ResultCard title={isZh ? "行业趋势分析" : "Industry Trend Analysis"} icon={Search} iconColor="text-blue-400">
      {/* Competitors */}
      {hasCompetitors && (
        <div>
          <p className="text-[11px] text-white/35 uppercase tracking-wider font-semibold mb-2">
            {isZh ? "监控竞品" : "Tracked Competitors"}
          </p>
          <div className="flex flex-wrap gap-1.5">
            {competitors.map((c) => (
              <div key={c.id} className="flex items-center gap-1.5 bg-blue-500/10 border border-blue-500/20 rounded-lg px-2 py-1">
                <Users className="h-3 w-3 text-blue-400" />
                <span className="text-xs text-blue-200">{c.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Real TikTok trending content */}
      <div>
        <p className="text-[11px] text-white/35 uppercase tracking-wider font-semibold mb-2">
          {isZh ? "行业热门内容（TikTok 实时）" : "Trending Content (TikTok Live)"}
        </p>
        {trendingLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-14 rounded-xl bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {(trending ?? []).slice(0, 3).map((v) => (
              <div key={v.id} className="flex gap-2.5 bg-white/5 rounded-xl p-2 border border-white/8">
                <div className="h-12 w-9 rounded-lg bg-white/10 shrink-0 overflow-hidden">
                  {v.thumbnailUrl && <img src={v.thumbnailUrl} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-white/80 line-clamp-1 leading-tight">{v.title}</p>
                  <div className="flex gap-2.5 mt-1 text-[10px] text-white/40">
                    <span className="flex items-center gap-0.5"><Eye className="h-2.5 w-2.5" />{v.views ?? "—"}</span>
                    <span className="flex items-center gap-0.5"><Heart className="h-2.5 w-2.5" />{v.likes ?? "—"}</span>
                    <span className="flex items-center gap-0.5"><MessageCircle className="h-2.5 w-2.5" />{v.comments ?? "—"}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Key insights */}
      <div>
        <p className="text-[11px] text-white/35 uppercase tracking-wider font-semibold mb-2">
          {isZh ? "行业洞察" : "Key Insights"}
        </p>
        <div className="space-y-1.5">
          {insights.map((tip, i) => (
            <div key={i} className="flex items-start gap-2 text-xs">
              <span className="text-green-400 shrink-0 mt-0.5">→</span>
              <span className="text-white/60">{tip}</span>
            </div>
          ))}
        </div>
      </div>
    </ResultCard>
  );
}

function GenerateResult({ isZh }: { isZh: boolean }) {
  const [copied, setCopied] = useState<number | null>(null);
  const captions = isZh
    ? [
        { platform: "facebook", text: "✨ 夏日美肌特惠！现在预约护肤套餐享 8 折优惠，名额有限，先到先得 💆‍♀️ #美容沙龙 #夏日特惠 #护肤" },
        { platform: "instagram", text: "🌟 NEW ARRIVAL | 我们的明星产品回来了！你最爱的胶原蛋白面膜全面上架，点击主页链接立即抢购 → #护肤 #美容" },
        { platform: "tiktok", text: "今日特供 ☕ 双人套餐第二份半价！周末限定，带上你的闺蜜来打卡吧～ #美容打卡 #周末特惠 📸" },
      ]
    : [
        { platform: "facebook", text: "✨ Summer Glow Special! Book your skincare package now and save 20% — limited slots 💆‍♀️ #beautysalon #summerdeal" },
        { platform: "instagram", text: "🌟 NEW ARRIVAL | Our best-selling collagen mask is back! Click the link in bio to shop now → #skincare #beauty" },
        { platform: "tiktok", text: "Today only ☕ Buy 1 Get 1 Half Price on all duo packages! Tag a bestie 📸 #beautytok #weekendvibes" },
      ];
  const platformColors: Record<string, string> = {
    facebook: "bg-blue-500/20 text-blue-300 border-blue-500/30",
    instagram: "bg-pink-500/20 text-pink-300 border-pink-500/30",
    tiktok: "bg-slate-500/20 text-slate-300 border-slate-500/30",
  };
  const PlatformIcons: Record<string, React.ElementType> = { facebook: Facebook, instagram: Instagram, tiktok: Video };

  const handleCopy = (text: string, idx: number) => {
    copyToClipboard(text);
    setCopied(idx);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <ResultCard title={isZh ? "AI 仿写文案" : "AI-Generated Captions"} icon={Sparkles} iconColor="text-yellow-400">
      <div className="space-y-2.5">
        {captions.map((c, i) => {
          const PIcon = PlatformIcons[c.platform];
          return (
            <div key={i} className="rounded-xl bg-black/30 border border-white/8 p-3">
              <div className="flex items-center justify-between mb-2">
                <Badge className={cn("text-[10px] px-2 py-0.5 border", platformColors[c.platform])}>
                  <PIcon className="h-3 w-3 mr-1" />{c.platform.charAt(0).toUpperCase() + c.platform.slice(1)}
                </Badge>
                <button
                  onClick={() => handleCopy(c.text, i)}
                  className="flex items-center gap-1 text-[10px] text-white/40 hover:text-white/70 transition-colors"
                >
                  {copied === i
                    ? <><CheckCircle2 className="h-3 w-3 text-green-400" /><span className="text-green-400">{isZh ? "已复制" : "Copied!"}</span></>
                    : <><RefreshCw className="h-3 w-3" />{isZh ? "复制" : "Copy"}</>}
                </button>
              </div>
              <p className="text-xs text-white/75 leading-relaxed">{c.text}</p>
              <p className="text-[10px] text-white/25 mt-1.5 text-right">{c.text.length} {isZh ? "字" : "chars"}</p>
            </div>
          );
        })}
      </div>
    </ResultCard>
  );
}

function ScheduleResult({ isZh, competitorCount }: { isZh: boolean; competitorCount: number }) {
  const schedule = [
    {
      platform: "Facebook", icon: Facebook, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20",
      day: isZh ? "周三" : "Wednesday", time: isZh ? "下午 1:00" : "1:00 PM",
      lift: "+18% CTR",
      caption: isZh ? "✨ 夏日美肌特惠！预约享 8 折..." : "✨ Summer Glow Special! Book now...",
    },
    {
      platform: "Instagram", icon: Instagram, color: "text-pink-400", bg: "bg-pink-500/10 border-pink-500/20",
      day: isZh ? "周一" : "Monday", time: isZh ? "早上 6:00" : "6:00 AM",
      lift: "+23% Eng",
      caption: isZh ? "🌟 明星胶原蛋白面膜回来了..." : "🌟 Collagen mask is back...",
    },
    {
      platform: "TikTok", icon: Video, color: "text-slate-300", bg: "bg-slate-500/10 border-slate-500/20",
      day: isZh ? "周四" : "Thursday", time: isZh ? "晚上 8:00" : "8:00 PM",
      lift: "+35% Views",
      caption: isZh ? "今日特供 ☕ 双人套餐半价..." : "Today only ☕ Buy 1 Get 1...",
    },
  ];

  return (
    <ResultCard title={isZh ? "智能排程计划" : "Smart Schedule"} icon={Calendar} iconColor="text-green-400">
      <div className="text-[11px] text-white/35 mb-1">
        {isZh
          ? `基于平台历史互动数据分析最佳排程时间`
          : `Optimized from platform engagement history & algorithm signals`}
      </div>
      <div className="space-y-2">
        {schedule.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.platform} className={cn("rounded-xl border p-3", s.bg)}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Icon className={cn("h-4 w-4", s.color)} />
                  <span className="text-xs font-semibold text-white/80">{s.platform}</span>
                </div>
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-[10px]">{s.lift}</Badge>
              </div>
              <div className="flex items-center gap-3 text-xs text-white/60 mb-1.5">
                <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{s.day}</span>
                <span>{s.time}</span>
              </div>
              <p className="text-[11px] text-white/40 italic truncate">{s.caption}</p>
            </div>
          );
        })}
      </div>
    </ResultCard>
  );
}

function AutoStepResults({ states, accounts, competitors, ayrshareConfigured, isZh }: {
  states: StepState[];
  accounts: AccountItem[];
  competitors: CompetitorItem[];
  ayrshareConfigured: boolean;
  isZh: boolean;
}) {
  if (states.every((s) => s === "pending")) return null;

  return (
    <div className="space-y-3">
      {states[0] === "done" && (
        <AuthResult isZh={isZh} accounts={accounts} ayrshareConfigured={ayrshareConfigured} />
      )}
      {states[1] === "done" && (
        <AnalyzeResult isZh={isZh} competitors={competitors} />
      )}
      {states[2] === "done" && (
        <GenerateResult isZh={isZh} />
      )}
      {states[3] === "done" && (
        <ScheduleResult isZh={isZh} competitorCount={competitors.length} />
      )}
    </div>
  );
}

// ── Setup checklist ────────────────────────────────────────────────────
function SetupChecklist({ lang, accounts, competitors, ayrshareConfigured }: {
  lang: string;
  accounts: number;
  competitors: number;
  ayrshareConfigured: boolean;
}) {
  const isZh = lang === "zh";
  const steps = [
    {
      label: isZh ? "连接社交账号" : "Connect social accounts",
      done: accounts > 0,
      href: "/accounts",
      hint: isZh ? `已连接 ${accounts} 个` : `${accounts} connected`,
    },
    {
      label: isZh ? "添加竞争对手" : "Add at least 1 competitor",
      done: competitors > 0,
      href: "/competitors",
      hint: isZh ? `已添加 ${competitors} 个` : `${competitors} added`,
    },
    {
      label: isZh ? "配置 Ayrshare API Key（多平台发布）" : "Configure Ayrshare API Key",
      done: ayrshareConfigured,
      href: "/accounts",
      hint: ayrshareConfigured ? (isZh ? "已配置" : "Configured") : (isZh ? "在 Secrets 中添加 AYRSHARE_API_KEY" : "Add AYRSHARE_API_KEY to Secrets"),
    },
  ];

  const allDone = steps.every((s) => s.done);

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-sm flex items-center gap-2">
          <Settings className="h-4 w-4 text-indigo-400" />
          {isZh ? "初始配置清单" : "Setup Checklist"}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {steps.map((step, i) => (
          <Link key={i} href={step.href}>
            <div className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 transition-colors cursor-pointer",
              step.done ? "bg-green-500/10 hover:bg-green-500/15" : "bg-white/5 hover:bg-white/10"
            )}>
              {step.done
                ? <CheckCircle2 className="h-4 w-4 text-green-400 shrink-0" />
                : <AlertCircle className="h-4 w-4 text-yellow-400 shrink-0" />}
              <div className="flex-1 min-w-0">
                <p className={cn("text-xs font-medium", step.done ? "text-green-300" : "text-white/80")}>{step.label}</p>
                <p className="text-[11px] text-white/40 truncate">{step.hint}</p>
              </div>
              {!step.done && <ArrowRight className="h-3 w-3 text-white/30 shrink-0" />}
            </div>
          </Link>
        ))}
        {allDone && (
          <div className="rounded-lg bg-indigo-500/20 border border-indigo-500/30 px-3 py-2 text-xs text-indigo-300 flex items-center gap-2">
            <Zap className="h-3.5 w-3.5" />
            {isZh ? "全部就绪 — 立即启动 AI！" : "All systems ready — start AI Autopilot!"}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ── Platform insight tabs ─────────────────────────────────────────────
function PlatformInsights({ lang, competitors }: { lang: string; competitors: string[] }) {
  const isZh = lang === "zh";
  const { data: trendingData } = useGetTrendingContent({ industry: "beauty" });

  const bestTimes = {
    tiktok: isZh
      ? ["周二、四、五晚 7-9 点互动最高", "视频时长 15-60 秒完播率最佳", "带话题标签可提升 40% 曝光"]
      : ["Tue/Thu/Fri 7-9pm gets highest engagement", "15-60s videos see best completion rate", "Hashtags boost reach by 40%"],
    facebook: isZh
      ? ["周二~四 下午 1-3 点点击率最高", "视频帖子比图文互动高 135%", "周三中午发帖覆盖率最广"]
      : ["Tue-Thu 1-3pm has highest CTR", "Video posts get 135% more engagement", "Wednesday noon posts reach widest audience"],
    instagram: isZh
      ? ["早 6 点和晚 7 点 Reel 互动最佳", "周一/周五发布涨粉最快", "Story 限时动态24小时引流效果显著"]
      : ["6am and 7pm Reels get peak engagement", "Mon/Fri posts grow followers fastest", "Stories drive 24h traffic spikes"],
  };

  return (
    <Card className="bg-white/5 border-white/10 overflow-hidden">
      <CardHeader className="pb-2">
        <CardTitle className="text-white text-sm flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-purple-400" />
          {isZh ? "各平台数据分析" : "Platform Intelligence"}
        </CardTitle>
      </CardHeader>
      <CardContent className="px-4 pb-4">
        <Tabs defaultValue="tiktok">
          <TabsList className="bg-white/10 border-white/10 mb-4 w-full">
            <TabsTrigger value="tiktok" className="flex-1 text-xs data-[state=active]:bg-white/20 data-[state=active]:text-white text-white/50">
              <Video className="h-3 w-3 mr-1" /> TikTok
            </TabsTrigger>
            <TabsTrigger value="facebook" className="flex-1 text-xs data-[state=active]:bg-white/20 data-[state=active]:text-white text-white/50">
              <Facebook className="h-3 w-3 mr-1" /> Facebook
            </TabsTrigger>
            <TabsTrigger value="instagram" className="flex-1 text-xs data-[state=active]:bg-white/20 data-[state=active]:text-white text-white/50">
              <Instagram className="h-3 w-3 mr-1" /> Instagram
            </TabsTrigger>
          </TabsList>

          {(["tiktok", "facebook", "instagram"] as const).map((platform) => (
            <TabsContent key={platform} value={platform} className="mt-0 space-y-3">
              {/* Best time tips */}
              <div className="space-y-1.5">
                {bestTimes[platform].map((tip, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs">
                    <span className="text-green-400 mt-0.5 shrink-0">→</span>
                    <span className="text-white/60">{tip}</span>
                  </div>
                ))}
              </div>

              {/* TikTok: real trending from TikHub */}
              {platform === "tiktok" && trendingData && trendingData.length > 0 && (
                <div className="space-y-2 mt-3">
                  <p className="text-[11px] text-white/40 uppercase tracking-wider font-semibold">
                    {isZh ? "行业热门视频（TikTok 实时）" : "Trending Videos (TikTok Live)"}
                  </p>
                  {trendingData.slice(0, 3).map((v) => (
                    <div key={v.id} className="flex gap-3 bg-white/5 rounded-lg p-2">
                      <div className="h-14 w-10 rounded bg-white/10 shrink-0 overflow-hidden">
                        {v.thumbnailUrl && <img src={v.thumbnailUrl} alt="" className="w-full h-full object-cover" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-white/80 line-clamp-2 leading-tight">{v.title}</p>
                        <div className="flex items-center gap-3 mt-1 text-[11px] text-white/50">
                          <span className="flex items-center gap-1"><Eye className="h-2.5 w-2.5" />{v.views ?? "—"}</span>
                          <span className="flex items-center gap-1"><Heart className="h-2.5 w-2.5" />{v.likes ?? "—"}</span>
                          <span className="flex items-center gap-1"><MessageCircle className="h-2.5 w-2.5" />{v.comments ?? "—"}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Competitor overview */}
              {competitors.length > 0 && (
                <div className="mt-2">
                  <p className="text-[11px] text-white/40 uppercase tracking-wider font-semibold mb-1.5">
                    {isZh ? "监控竞品" : "Tracked Competitors"}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {competitors.slice(0, 5).map((c, i) => (
                      <Badge key={i} className="bg-white/10 text-white/60 border-white/20 text-[10px]">
                        {c}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}

// ── Upload Content Form ───────────────────────────────────────────────
const PLATFORM_OPTIONS = [
  { key: "facebook",  label: "Facebook",  icon: Facebook },
  { key: "instagram", label: "Instagram", icon: Instagram },
  { key: "tiktok",    label: "TikTok",    icon: Video },
];

function UploadContentForm({
  isZh, locked, caption, setCaption, file, setFile,
  platforms, setPlatforms, scheduleAt, setScheduleAt, tU,
}: {
  isZh: boolean;
  locked: boolean;
  caption: string;
  setCaption: (v: string) => void;
  file: File | null;
  setFile: (f: File | null) => void;
  platforms: string[];
  setPlatforms: (p: string[]) => void;
  scheduleAt: string;
  setScheduleAt: (v: string) => void;
  tU: Record<string, string>;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [transcribeMsg, setTranscribeMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (locked) return;
    const f = e.dataTransfer.files[0];
    if (f) { setFile(f); setTranscribeMsg(null); }
  };

  const togglePlatform = (key: string) => {
    if (locked) return;
    setPlatforms(platforms.includes(key) ? platforms.filter((p) => p !== key) : [...platforms, key]);
  };

  const isVideo = file?.type.startsWith("video/");
  const isImage = file?.type.startsWith("image/");
  const previewUrl = file && isImage ? URL.createObjectURL(file) : null;

  const handleTranscribe = async () => {
    if (!file || !isVideo || transcribing) return;
    setTranscribing(true);
    setTranscribeMsg(null);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const resp = await fetch(`${BASE}/api/transcribe`, {
        method: "POST",
        headers: {
          "Content-Type": file.type || "video/mp4",
          "X-Filename": file.name,
          "X-Language": isZh ? "zh" : "en",
        },
        body: arrayBuffer,
      });
      const data = await resp.json() as { text?: string; error?: string; mock?: boolean };
      if (data.text) {
        setCaption(data.text);
        setTranscribeMsg({ ok: true, text: data.mock ? (isZh ? "示例转录已填入（配置 OPENAI_API_KEY 启用真实 Whisper）" : "Sample transcription filled in (add OPENAI_API_KEY for real Whisper)") : (isZh ? "Whisper 转录成功，已填入文案框" : "Whisper transcription complete") });
      } else {
        setTranscribeMsg({ ok: false, text: data.error || (isZh ? "转录失败，请重试" : "Transcription failed") });
      }
    } catch {
      setTranscribeMsg({ ok: false, text: isZh ? "网络错误，请重试" : "Network error, please retry" });
    } finally {
      setTranscribing(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Drop zone */}
      <div>
        <p className="text-xs text-white/50 mb-2 font-medium uppercase tracking-wide">{tU.uploadLabel}</p>
        <div
          className={cn(
            "relative border-2 border-dashed rounded-xl p-5 text-center transition-all duration-200 cursor-pointer",
            locked ? "opacity-60 cursor-not-allowed" : "cursor-pointer",
            dragging ? "border-violet-400 bg-violet-500/10" : file ? "border-violet-500/40 bg-violet-500/5" : "border-white/15 hover:border-white/30 hover:bg-white/5",
          )}
          onClick={() => !locked && inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
        >
          <input
            ref={inputRef}
            type="file"
            accept="video/*,image/*"
            className="hidden"
            disabled={locked}
            onChange={(e) => { const f = e.target.files?.[0]; if (f) setFile(f); }}
          />
          {file ? (
            <div className="flex items-center gap-3">
              {previewUrl ? (
                <img src={previewUrl} alt="" className="h-14 w-14 rounded-lg object-cover shrink-0 border border-white/10" />
              ) : (
                <div className="h-14 w-14 rounded-lg bg-violet-500/20 flex items-center justify-center shrink-0">
                  {isVideo ? <FileVideo className="h-7 w-7 text-violet-400" /> : <FileImage className="h-7 w-7 text-violet-400" />}
                </div>
              )}
              <div className="flex-1 text-left min-w-0">
                <p className="text-sm text-white/90 truncate font-medium">{file.name}</p>
                <p className="text-xs text-violet-300 mt-0.5">{tU.fileReady} ✓ — {(file.size / 1024 / 1024).toFixed(1)} MB</p>
              </div>
              {!locked && (
                <button
                  onClick={(e) => { e.stopPropagation(); setFile(null); }}
                  className="h-7 w-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center shrink-0"
                >
                  <X className="h-3.5 w-3.5 text-white/60" />
                </button>
              )}
            </div>
          ) : (
            <div className="py-2">
              <Upload className="h-8 w-8 text-white/20 mx-auto mb-2" />
              <p className="text-xs text-white/40">{tU.uploadHint}</p>
            </div>
          )}
        </div>
      </div>

      {/* Whisper transcribe button — shows only for video files */}
      {file && isVideo && !locked && (
        <div className="space-y-1.5">
          <button
            onClick={handleTranscribe}
            disabled={transcribing}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-violet-500/30 bg-violet-500/10 text-violet-300 text-xs font-medium hover:bg-violet-500/20 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {transcribing
              ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" />{isZh ? "Whisper AI 转录中..." : "Transcribing with Whisper..."}</>
              : <><Mic2 className="h-3.5 w-3.5" />{isZh ? "✦ AI 语音转文字（Whisper）— 自动填写文案" : "✦ Transcribe Audio with Whisper AI"}</>}
          </button>
          {transcribeMsg && (
            <div className={cn(
              "flex items-start gap-2 rounded-lg px-3 py-2 text-[11px]",
              transcribeMsg.ok ? "bg-green-500/10 text-green-300 border border-green-500/20" : "bg-red-500/10 text-red-300 border border-red-500/20",
            )}>
              {transcribeMsg.ok ? <CheckCircle2 className="h-3.5 w-3.5 shrink-0 mt-0.5" /> : <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />}
              {transcribeMsg.text}
            </div>
          )}
        </div>
      )}

      {/* Caption */}
      <div>
        <label className="text-xs text-white/50 mb-2 font-medium uppercase tracking-wide block">{tU.captionLabel}</label>
        <textarea
          className="w-full rounded-xl bg-white/5 border border-white/10 text-white/80 text-sm px-3 py-2.5 resize-none focus:outline-none focus:border-violet-500/50 placeholder:text-white/25 disabled:opacity-60"
          rows={3}
          disabled={locked}
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder={tU.captionPlaceholder}
          maxLength={2200}
        />
        <p className="text-right text-[10px] text-white/25 mt-0.5">{caption.length}/2200</p>
      </div>

      {/* Platforms */}
      <div>
        <label className="text-xs text-white/50 mb-2 font-medium uppercase tracking-wide block">{tU.platformsLabel}</label>
        <div className="flex gap-2">
          {PLATFORM_OPTIONS.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              disabled={locked}
              onClick={() => togglePlatform(key)}
              className={cn(
                "flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl border text-xs font-medium transition-all",
                platforms.includes(key)
                  ? "bg-violet-600/30 border-violet-500/50 text-violet-200"
                  : "bg-white/5 border-white/10 text-white/40 hover:border-white/25",
                locked && "cursor-not-allowed opacity-60",
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Schedule */}
      <div>
        <label className="text-xs text-white/50 mb-2 font-medium uppercase tracking-wide block">{tU.scheduleLabel}</label>
        <div className="flex gap-2">
          <button
            disabled={locked}
            onClick={() => setScheduleAt("")}
            className={cn(
              "flex-1 py-2 rounded-xl border text-xs font-medium transition-all",
              !scheduleAt ? "bg-green-600/30 border-green-500/50 text-green-200" : "bg-white/5 border-white/10 text-white/40 hover:border-white/25",
              locked && "cursor-not-allowed",
            )}
          >
            {tU.scheduleNow}
          </button>
          <input
            type="datetime-local"
            disabled={locked}
            value={scheduleAt}
            onChange={(e) => setScheduleAt(e.target.value)}
            className="flex-1 rounded-xl bg-white/5 border border-white/10 text-white/60 text-xs px-3 py-2 focus:outline-none focus:border-violet-500/50 disabled:opacity-60 [color-scheme:dark]"
          />
        </div>
      </div>
    </div>
  );
}

export default function AiAutopilotPage() {
  const { t, lang } = useLang();
  const tA = t.aiAutopilot;
  const { data: competitors } = useListCompetitors();
  const { data: contentItems } = useListContentItems();
  const { data: summary } = useGetAnalyticsSummary();
  const { data: accounts } = useListAccounts();

  const [ayrshareConfigured, setAyrshareConfigured] = useState(false);
  useEffect(() => {
    fetch(`${BASE}/api/social-accounts/ayrshare/status`)
      .then((r) => r.json())
      .then((d: { configured?: boolean }) => setAyrshareConfigured(d.configured ?? false))
      .catch(() => {});
  }, []);

  // mode: "auto" = AI full pipeline | "upload" = customer-supplied content
  const [mode, setMode] = useState<"auto" | "upload">("auto");
  // upload form state
  const [uploadCaption, setUploadCaption] = useState("");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadPlatforms, setUploadPlatforms] = useState<string[]>(["facebook", "instagram"]);
  const [uploadScheduleAt, setUploadScheduleAt] = useState("");
  const [uploadError, setUploadError] = useState("");

  const [, navigate] = useLocation();
  const [showAccountGate, setShowAccountGate] = useState(false);

  const [states, setStates] = useState<StepState[]>(["pending", "pending", "pending", "pending", "pending"]);
  const [running, setRunning] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [progresses, setProgresses] = useState([0, 0, 0, 0, 0]);
  const logIdRef = useRef(0);

  const switchMode = (newMode: "auto" | "upload") => {
    if (running) return;
    setMode(newMode);
    setCompleted(false);
    setLogs([]);
    setUploadError("");
    const len = newMode === "upload" ? 4 : 5;
    setStates(Array(len).fill("pending") as StepState[]);
    setProgresses(Array(len).fill(0));
  };

  const addLog = (text: string) => {
    const now = new Date();
    const ts = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`;
    setLogs((prev) => [...prev, { id: logIdRef.current++, text, ts }]);
  };

  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

  const buildLogs = (): string[][] => {
    const ll = tA.logLabels;
    const isZh = lang === "zh";
    const competitorNames = competitors?.map((c) => c.name) ?? ["Rival Salon A", "Beauty Bar B"];
    const accountCount = accounts?.length ?? 0;
    const keywords = isZh
      ? ["#护肤", "#美甲", "#美发", "#促销优惠", "#周末特惠"]
      : ["#skincare", "#nails", "#hairsalon", "#weekendoffer", "#beauty"];

    return [
      // Step 0: 账号授权验证
      [
        isZh ? "检查 Facebook 账号授权状态..." : "Checking Facebook account authorization...",
        accountCount > 0
          ? isZh ? `✓ Facebook 已授权 — ${accountCount} 个账号就绪` : `✓ Facebook authorized — ${accountCount} account(s) ready`
          : isZh ? "⚠ Facebook 未连接，建议前往社交账号页面授权" : "⚠ Facebook not connected — visit Social Accounts to link",
        isZh ? "检查 Instagram 账号授权状态..." : "Checking Instagram account authorization...",
        isZh ? "检查 TikTok（Ayrshare）授权状态..." : "Checking TikTok (Ayrshare) authorization...",
        ayrshareConfigured
          ? isZh ? "✓ Ayrshare API 已配置 — TikTok 发布就绪" : "✓ Ayrshare API configured — TikTok publishing ready"
          : isZh ? "⚠ Ayrshare 未配置，TikTok 发布将跳过" : "⚠ Ayrshare not configured — TikTok publishing will be skipped",
        isZh ? "✓ 账号授权检查完成，继续下一步" : "✓ Account authorization check complete",
      ],
      // Step 1: 竞品行业分析
      [
        isZh ? `扫描竞品账号：${competitorNames.slice(0, 2).join("、") || "暂无竞品"}...` : `Scanning competitors: ${competitorNames.slice(0, 2).join(", ") || "none added yet"}...`,
        isZh ? "TikHub: 抓取行业热门视频数据..." : "TikHub: fetching industry trending video data...",
        `${ll.analyzing} ${keywords[0]}, ${keywords[1]}...`,
        `${ll.analyzing} ${keywords[2]}, ${keywords[3]}...`,
        isZh ? `✓ 发现 ${keywords.length} 个热门话题` : `✓ Found ${keywords.length} trending topics`,
        isZh ? "→ 洞察：周末护肤套餐互动率最高，美甲短视频涨粉最快" : "→ Insight: Weekend skincare bundles drive highest engagement; nail videos grow followers fastest",
      ],
      // Step 2: AI 仿写内容
      [
        isZh ? "提取竞品高互动内容风格..." : "Extracting high-engagement content style from competitors...",
        isZh ? "AI 仿写文案 #1（参考竞品爆款格式）..." : "AI mimicking competitor post style — caption #1...",
        isZh ? "✦ 夏日美肌特惠！现在预约享 8 折优惠 💆 #美容 #护肤" : "✦ Summer Glow Special! Book now for 20% off 💆 #beauty #skincare",
        isZh ? "AI 仿写文案 #2..." : "AI mimicking competitor post style — caption #2...",
        isZh ? "✦ NEW ARRIVAL | 明星胶原蛋白面膜已上架，限量预售 →" : "✦ NEW ARRIVAL | Collagen mask back in stock — limited presale →",
        isZh ? `✓ 已仿写生成 3 条高质量文案，匹配行业爆款风格` : "✓ Generated 3 AI captions matching top-performing industry style",
      ],
      // Step 3: 智能排程
      [
        isZh ? "基于平台算法分析最佳发布时间..." : "Analyzing platform algorithms for optimal posting times...",
        isZh ? "→ TikTok: 周四晚 8 点 — 互动率峰值" : "→ TikTok: Thu 8:00 PM — peak engagement window",
        isZh ? "→ Instagram: 周一早 6 点 — Reels 最优时段" : "→ Instagram: Mon 6:00 AM — best for Reels",
        isZh ? "→ Facebook: 周三下午 1 点 — 点击率最高" : "→ Facebook: Wed 1:00 PM — highest CTR",
        isZh ? "自动写入排程计划..." : "Writing schedule plan...",
        isZh ? `✓ 3 条内容已智能排程` : `✓ 3 posts scheduled at optimal times`,
      ],
      // Step 4: 多平台发布
      [
        `${ll.publishing} Facebook...`,
        `${ll.done} ✓ fb_post_${Date.now().toString().slice(-6)}`,
        `${ll.publishing} Instagram Reels...`,
        `${ll.done} ✓ ig_reel_${Date.now().toString().slice(-6)}`,
        `${ll.publishing} TikTok via Ayrshare...`,
        `${ll.done} ✓ tk_video_${Date.now().toString().slice(-6)}`,
        isZh ? "✓ 三平台全部发布完成 🎉" : "✓ All 3 platforms published successfully 🎉",
      ],
    ];
  };

  const buildUploadLogs = (): string[][] => {
    const isZh = lang === "zh";
    const accountCount = accounts?.length ?? 0;
    const fileName = uploadFile?.name ?? (isZh ? "用户提交内容" : "user_content");
    const captionPreview = uploadCaption.slice(0, 40) + (uploadCaption.length > 40 ? "..." : "");
    const platformList = uploadPlatforms.map((p) => p === "tiktok" ? "TikTok" : p.charAt(0).toUpperCase() + p.slice(1)).join(", ") || (isZh ? "无平台选择" : "none");

    return [
      // Step 0: 账号授权验证
      [
        isZh ? "检查 Facebook 账号授权状态..." : "Checking Facebook account authorization...",
        accountCount > 0
          ? isZh ? `✓ Facebook 已授权 — ${accountCount} 个账号就绪` : `✓ Facebook authorized — ${accountCount} account(s) ready`
          : isZh ? "⚠ Facebook 未连接，建议前往社交账号页面授权" : "⚠ Facebook not connected — visit Social Accounts to link",
        isZh ? "检查 Instagram 账号授权状态..." : "Checking Instagram account authorization...",
        isZh ? "检查 TikTok（Ayrshare）授权状态..." : "Checking TikTok (Ayrshare) authorization...",
        ayrshareConfigured
          ? isZh ? "✓ Ayrshare API 已配置 — TikTok 发布就绪" : "✓ Ayrshare API configured — TikTok ready"
          : isZh ? "⚠ Ayrshare 未配置，TikTok 将跳过" : "⚠ Ayrshare not configured — TikTok skipped",
        isZh ? "✓ 账号授权检查完成" : "✓ Authorization check complete",
      ],
      // Step 1: 内容上传与确认
      [
        uploadFile
          ? (isZh ? `加载文件：${fileName}` : `Loading file: ${fileName}`)
          : (isZh ? "未检测到文件，使用纯文案模式..." : "No file detected — text-only mode..."),
        uploadFile
          ? (isZh ? `✓ 文件校验通过 (${(uploadFile.size / 1024 / 1024).toFixed(1)} MB)` : `✓ File validated (${(uploadFile.size / 1024 / 1024).toFixed(1)} MB)`)
          : (isZh ? "✓ 纯文案内容就绪" : "✓ Text caption ready"),
        uploadCaption
          ? (isZh ? `文案：${captionPreview}` : `Caption: ${captionPreview}`)
          : (isZh ? "⚠ 未输入文案，将使用默认模板" : "⚠ No caption entered — default template will be used"),
        isZh ? `发布平台：${platformList}` : `Publishing to: ${platformList}`,
        uploadScheduleAt
          ? (isZh ? `排程时间：${new Date(uploadScheduleAt).toLocaleString("zh-CN")}` : `Scheduled for: ${new Date(uploadScheduleAt).toLocaleString("en-US")}`)
          : (isZh ? "发布方式：立即发布" : "Mode: Publish immediately"),
        isZh ? "✓ 内容确认完成，进入排程" : "✓ Content confirmed — proceeding to schedule",
      ],
      // Step 2: 智能排程
      [
        isZh ? "读取各平台最佳发布时间数据..." : "Loading platform-specific optimal posting times...",
        uploadPlatforms.includes("facebook") ? (isZh ? "→ Facebook: 周三下午 1 点 — 点击率最高" : "→ Facebook: Wed 1:00 PM — highest CTR") : null,
        uploadPlatforms.includes("instagram") ? (isZh ? "→ Instagram: 周一早 6 点 — Reels 最优时段" : "→ Instagram: Mon 6:00 AM — best for Reels") : null,
        uploadPlatforms.includes("tiktok") ? (isZh ? "→ TikTok: 周四晚 8 点 — 互动率峰值" : "→ TikTok: Thu 8:00 PM — peak engagement") : null,
        isZh ? "写入排程任务..." : "Writing schedule task...",
        uploadScheduleAt
          ? (isZh ? `✓ 已排程至 ${new Date(uploadScheduleAt).toLocaleString("zh-CN")}` : `✓ Scheduled for ${new Date(uploadScheduleAt).toLocaleString("en-US")}`)
          : (isZh ? "✓ 已加入立即发布队列" : "✓ Added to immediate publish queue"),
      ].filter(Boolean) as string[],
      // Step 3: 多平台发布
      [
        ...uploadPlatforms.map((p) => {
          const name = p === "tiktok" ? "TikTok via Ayrshare" : p.charAt(0).toUpperCase() + p.slice(1);
          return isZh ? `正在发布至 ${name}...` : `Publishing to ${name}...`;
        }),
        ...uploadPlatforms.map((p) => {
          const tag = `${p.slice(0, 2)}_${Date.now().toString().slice(-6)}`;
          return isZh ? `✓ 发布成功 — ${tag}` : `✓ Published — ${tag}`;
        }),
        isZh ? `✓ ${uploadPlatforms.length} 个平台发布完成 🎉` : `✓ Published to ${uploadPlatforms.length} platform(s) successfully 🎉`,
      ],
    ];
  };

  const runPipeline = async (stepLogs: string[][], durations: number[], stepsCount: number) => {
    for (let s = 0; s < stepsCount; s++) {
      setStates((prev) => { const n = [...prev] as StepState[]; n[s] = "running"; return n; });
      const duration = durations[s];
      const logEntries = stepLogs[s];
      const logInterval = duration / (logEntries.length + 1);
      for (let li = 0; li < logEntries.length; li++) {
        await sleep(logInterval);
        addLog(logEntries[li]);
        const pct = Math.round(((li + 1) / logEntries.length) * 100);
        setProgresses((prev) => { const n = [...prev]; n[s] = pct; return n; });
      }
      await sleep(300);
      setStates((prev) => { const n = [...prev] as StepState[]; n[s] = "done"; return n; });
      setProgresses((prev) => { const n = [...prev]; n[s] = 100; return n; });
    }
  };

  const handleStart = async () => {
    setUploadError("");
    // Block if no accounts connected at all — prompt user to link first
    const hasAccount = (accounts?.length ?? 0) > 0;
    if (!hasAccount && !ayrshareConfigured) {
      setShowAccountGate(true);
      return;
    }
    if (mode === "upload") {
      if (!uploadFile && !uploadCaption.trim()) { setUploadError(tA.uploadMode.requireFile); return; }
      if (uploadPlatforms.length === 0) { setUploadError(tA.uploadMode.requirePlatform); return; }
    }
    const isUpload = mode === "upload";
    const stepsCount = isUpload ? 4 : 5;
    setRunning(true);
    setCompleted(false);
    setLogs([]);
    setStates(Array(stepsCount).fill("pending") as StepState[]);
    setProgresses(Array(stepsCount).fill(0));
    const stepLogs = isUpload ? buildUploadLogs() : buildLogs();
    const durations = isUpload ? UPLOAD_STEP_DURATIONS : STEP_DURATIONS;
    await runPipeline(stepLogs, durations, stepsCount);
    setRunning(false);
    setCompleted(true);
  };

  const handleReset = () => {
    setCompleted(false);
    setUploadError("");
    const len = mode === "upload" ? 4 : 5;
    setStates(Array(len).fill("pending") as StepState[]);
    setLogs([]);
    setProgresses(Array(len).fill(0));
  };

  const isUploadMode = mode === "upload";
  const currentSteps = isUploadMode ? UPLOAD_STEPS : STEPS;
  const autoStepKeys = ["auth", "analyze", "generate", "schedule", "publish"] as const;
  const uploadStepKeys = ["auth", "upload", "schedule", "publish"] as const;
  const currentStepKeys = isUploadMode ? uploadStepKeys : autoStepKeys;
  const competitorNames = competitors?.map((c) => c.name) ?? [];

  const isZh = lang === "zh";

  return (
    <div className="min-h-screen -m-8 bg-gradient-to-br from-gray-950 via-slate-900 to-indigo-950 p-8">

      {/* ── Account gate modal — blocks run when no accounts linked ── */}
      {showAccountGate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-gray-900 border border-white/15 rounded-2xl shadow-2xl max-w-sm w-full mx-4 p-7 space-y-5 animate-in zoom-in-95 duration-200">
            {/* Icon */}
            <div className="h-14 w-14 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center mx-auto">
              <KeyRound className="h-7 w-7 text-amber-400" />
            </div>
            {/* Copy */}
            <div className="text-center space-y-1.5">
              <h2 className="text-white font-bold text-lg">
                {isZh ? "先连接社交账号" : "Connect your accounts first"}
              </h2>
              <p className="text-white/50 text-sm leading-relaxed">
                {isZh
                  ? "AI 自动驾驶需要授权至少一个社交平台账号（Facebook / Instagram / TikTok），才能真实发布内容。"
                  : "AI Autopilot needs at least one connected social account (Facebook / Instagram / TikTok) to publish real content."}
              </p>
            </div>
            {/* Platforms hint */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { name: "Facebook", icon: Facebook, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
                { name: "Instagram", icon: Instagram, color: "text-pink-400", bg: "bg-pink-500/10 border-pink-500/20" },
                { name: "TikTok", icon: Video, color: "text-slate-300", bg: "bg-slate-500/10 border-slate-500/20" },
              ].map(({ name, icon: Icon, color, bg }) => (
                <div key={name} className={cn("flex flex-col items-center gap-1.5 rounded-xl border py-3", bg)}>
                  <Icon className={cn("h-5 w-5", color)} />
                  <span className="text-[10px] text-white/50">{name}</span>
                </div>
              ))}
            </div>
            {/* CTAs */}
            <div className="space-y-2">
              <button
                onClick={() => { setShowAccountGate(false); navigate("/accounts"); }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-500/20"
              >
                <ArrowRight className="h-4 w-4" />
                {isZh ? "前往连接社交账号" : "Go to Social Accounts"}
              </button>
              <button
                onClick={() => setShowAccountGate(false)}
                className="w-full py-2.5 rounded-xl border border-white/10 text-white/40 hover:text-white/60 text-sm transition-colors"
              >
                {isZh ? "稍后再说" : "Maybe later"}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto space-y-6 animate-in fade-in duration-500">

        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
                <Bot className="h-6 w-6 text-white" />
              </div>
              <Badge className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30 text-xs">
                <Zap className="h-3 w-3 mr-1" />
                {tA.badge}
              </Badge>
            </div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{tA.title}</h1>
            <p className="text-white/50 mt-1 text-sm">{tA.subtitle}</p>
          </div>
          <div>
            {!running && !completed && (
              <Button
                onClick={handleStart}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-lg shadow-indigo-500/30 h-12 px-8 text-base"
              >
                <Play className="h-5 w-5 mr-2" />
                {tA.startBtn}
              </Button>
            )}
            {running && (
              <Button disabled className="h-12 px-8 text-base bg-indigo-600/50 text-white/60">
                <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                {tA.runningBtn}
              </Button>
            )}
            {completed && (
              <Button
                onClick={handleReset}
                variant="outline"
                className="h-12 px-8 text-base border-indigo-500/40 text-indigo-300 hover:bg-indigo-500/10"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                {tA.completeBtn}
              </Button>
            )}
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4">
          {[
            { icon: Users,     label: lang === "zh" ? "监控对手" : "Competitors",    value: competitors?.length ?? 0, color: "text-blue-400" },
            { icon: ImageIcon, label: lang === "zh" ? "内容素材" : "Content Items",  value: contentItems?.length ?? 0, color: "text-yellow-400" },
            { icon: Send,      label: lang === "zh" ? "本周发布" : "Published",      value: summary?.publishedThisWeek ?? 0, color: "text-green-400" },
          ].map((s) => (
            <Card key={s.label} className="bg-white/5 border-white/10">
              <CardContent className="p-4 flex items-center gap-3">
                <s.icon className={cn("h-8 w-8", s.color)} />
                <div>
                  <div className="text-2xl font-bold text-white">{s.value}</div>
                  <div className="text-xs text-white/40">{s.label}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Mode toggle */}
        <div className="flex gap-2 bg-white/5 border border-white/10 rounded-2xl p-1.5 w-fit">
          <button
            disabled={running}
            onClick={() => switchMode("auto")}
            className={cn(
              "flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200",
              mode === "auto"
                ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30"
                : "text-white/50 hover:text-white/80 hover:bg-white/5",
              running && "cursor-not-allowed opacity-60",
            )}
          >
            <Bot className="h-4 w-4" />
            {tA.uploadMode.modeAuto}
          </button>
          <button
            disabled={running}
            onClick={() => switchMode("upload")}
            className={cn(
              "flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200",
              mode === "upload"
                ? "bg-gradient-to-r from-violet-600 to-pink-600 text-white shadow-lg shadow-violet-500/30"
                : "text-white/50 hover:text-white/80 hover:bg-white/5",
              running && "cursor-not-allowed opacity-60",
            )}
          >
            <UploadCloud className="h-4 w-4" />
            {tA.uploadMode.modeUpload}
          </button>
        </div>

        {/* Mode description banner */}
        <div className={cn(
          "rounded-xl border px-4 py-3 text-sm transition-all duration-300",
          mode === "auto" ? "bg-indigo-500/10 border-indigo-500/20 text-indigo-300" : "bg-violet-500/10 border-violet-500/20 text-violet-300",
        )}>
          {mode === "auto" ? tA.uploadMode.modeAutoDesc : tA.uploadMode.modeUploadDesc}
        </div>

        {/* Main layout: steps + center + sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

          {/* Left: steps (dynamic based on mode) */}
          <div className="lg:col-span-3 space-y-3">
            {currentSteps.map((step, i) => (
              <StepCard
                key={step.id}
                step={step}
                state={states[i] ?? "pending"}
                title={tA.steps[currentStepKeys[i]].title}
                desc={tA.steps[currentStepKeys[i]].desc}
                progress={progresses[i] ?? 0}
              />
            ))}
          </div>

          {/* Center: upload form (upload mode) or log + AI preview (auto mode) */}
          <div className="lg:col-span-5 space-y-4">

            {/* Upload form — only in upload mode, hidden while running */}
            {isUploadMode && (
              <Card className={cn("border overflow-hidden transition-all", running ? "bg-white/3 border-white/5 opacity-70" : "bg-white/5 border-white/10")}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-white/80 text-sm flex items-center gap-2">
                    <UploadCloud className="h-4 w-4 text-violet-400" />
                    {lang === "zh" ? "上传您的内容" : "Your Content"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="px-4 pb-4">
                  <UploadContentForm
                    isZh={lang === "zh"}
                    locked={running || completed}
                    caption={uploadCaption}
                    setCaption={setUploadCaption}
                    file={uploadFile}
                    setFile={setUploadFile}
                    platforms={uploadPlatforms}
                    setPlatforms={setUploadPlatforms}
                    scheduleAt={uploadScheduleAt}
                    setScheduleAt={setUploadScheduleAt}
                    tU={tA.uploadMode as unknown as Record<string, string>}
                  />
                  {uploadError && (
                    <div className="mt-3 flex items-center gap-2 text-red-400 text-xs bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
                      <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                      {uploadError}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Live log — always visible */}
            <Card className="bg-white/5 border-white/10 overflow-hidden">
              <CardHeader className="pb-2 flex flex-row items-center gap-2">
                <div className={cn("h-2 w-2 rounded-full", running ? "bg-green-400 animate-pulse" : "bg-white/20")} />
                <CardTitle className="text-white/70 text-sm font-mono">
                  {lang === "zh" ? "实时日志" : "Live Log"}
                </CardTitle>
                {running && <Badge className="ml-auto bg-green-500/20 text-green-300 border-green-500/30 text-[10px]">LIVE</Badge>}
              </CardHeader>
              <CardContent className="pt-0 pb-4 px-4">
                <LogPanel logs={logs} />
              </CardContent>
            </Card>

            {/* Step result cards — auto mode only, appear progressively as steps complete */}
            {!isUploadMode && (
              <AutoStepResults
                states={states}
                accounts={(accounts ?? []) as AccountItem[]}
                competitors={(competitors ?? []) as CompetitorItem[]}
                ayrshareConfigured={ayrshareConfigured}
                isZh={lang === "zh"}
              />
            )}

            {/* Pipeline progress bar */}
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <div className="flex items-center justify-between text-xs text-white/40 mb-3">
                  <span>{lang === "zh" ? "流程进度" : "Pipeline Progress"}</span>
                  <span>{states.filter((s) => s === "done").length} / {currentSteps.length}</span>
                </div>
                <div className="flex items-center gap-1">
                  {currentSteps.map((step, i) => {
                    const Icon = step.icon;
                    const st = states[i] ?? "pending";
                    return (
                      <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
                        <div className={cn(
                          "h-8 w-full rounded-lg flex items-center justify-center transition-all duration-500",
                          st === "done" ? "bg-green-500/30 border border-green-500/40"
                            : st === "running" ? `${step.bgColor} border ${step.borderColor} animate-pulse`
                            : "bg-white/5 border border-white/10"
                        )}>
                          {st === "done"
                            ? <CheckCircle2 className="h-4 w-4 text-green-400" />
                            : <Icon className={cn("h-4 w-4", st === "running" ? step.color : "text-white/20")} />}
                        </div>
                        {i < currentSteps.length - 1 && (
                          <ChevronRight className={cn("h-3 w-3 -mt-1 shrink-0", st === "done" ? "text-green-400/50" : "text-white/15")} />
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Completion banner */}
            {completed && (
              <div className={cn(
                "rounded-2xl border p-5 animate-in fade-in slide-in-from-bottom-4 duration-500",
                isUploadMode
                  ? "bg-gradient-to-r from-violet-500/20 to-pink-500/20 border-violet-500/30"
                  : "bg-gradient-to-r from-green-500/20 to-emerald-500/20 border-green-500/30",
              )}>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className={cn("h-6 w-6 shrink-0 mt-0.5", isUploadMode ? "text-violet-400" : "text-green-400")} />
                  <div>
                    <p className={cn("font-semibold", isUploadMode ? "text-violet-300" : "text-green-300")}>
                      {isUploadMode
                        ? (lang === "zh" ? `内容已成功发布到 ${uploadPlatforms.length} 个平台 🎉` : `Content published to ${uploadPlatforms.length} platform(s) 🎉`)
                        : tA.complete}
                    </p>
                    <p className={cn("text-xs mt-1", isUploadMode ? "text-violet-400/60" : "text-green-400/60")}>
                      {lang === "zh"
                        ? `完成时间: ${new Date().toLocaleTimeString("zh-CN")}`
                        : `Completed at: ${new Date().toLocaleTimeString("en-US")}`}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right: setup checklist + platform insights */}
          <div className="lg:col-span-4 space-y-4">
            <SetupChecklist
              lang={lang}
              accounts={accounts?.length ?? 0}
              competitors={competitors?.length ?? 0}
              ayrshareConfigured={ayrshareConfigured}
            />
            <PlatformInsights lang={lang} competitors={competitorNames} />
          </div>
        </div>
      </div>
    </div>
  );
}
