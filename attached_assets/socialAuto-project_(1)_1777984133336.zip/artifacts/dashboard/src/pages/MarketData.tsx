import { 
  useSearchAdLibrary, 
  useGetTrendingContent 
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Search, TrendingUp, Megaphone, ExternalLink,
  Eye, MessageCircle, ThumbsUp, Video,
  Flame, Sparkles, RefreshCw, BookOpen,
} from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLang } from "@/contexts/LanguageContext";
import { getSearchAdLibraryQueryKey } from "@workspace/api-client-react";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function MarketDataPage() {
  const { t } = useLang();
  const [activeTab, setActiveTab] = useState("ads");

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">{t.marketData.title}</h1>
        <p className="text-muted-foreground mt-1">{t.marketData.subtitle}</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-muted/50 p-1 rounded-xl">
          <TabsTrigger value="ads" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Megaphone className="h-4 w-4 mr-2" /> {t.marketData.metaAdLibrary}
          </TabsTrigger>
          <TabsTrigger value="trending" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <TrendingUp className="h-4 w-4 mr-2" /> {t.marketData.trending}
          </TabsTrigger>
          <TabsTrigger value="social-crawl" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Flame className="h-4 w-4 mr-2" /> 社交爬虫
          </TabsTrigger>
        </TabsList>

        <TabsContent value="ads" className="space-y-6">
          <AdLibrarySection />
        </TabsContent>

        <TabsContent value="trending" className="space-y-6">
          <TrendingContentSection />
        </TabsContent>

        <TabsContent value="social-crawl" className="space-y-6">
          <SocialCrawlSection />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ── Ad Library ──────────────────────────────────────────────────────────
function AdLibrarySection() {
  const [keyword, setKeyword] = useState("");
  const [searchTrigger, setSearchTrigger] = useState("");
  
  const { data: ads, isLoading } = useSearchAdLibrary(
    { keyword: searchTrigger },
    { query: { enabled: !!searchTrigger, queryKey: getSearchAdLibraryQueryKey({ keyword: searchTrigger }) } }
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchTrigger(keyword);
  };

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-sm bg-white dark:bg-gray-900">
        <CardHeader>
          <CardTitle>Meta Ad Library Search</CardTitle>
          <CardDescription>Search for active ads from your competitors on Facebook and Instagram.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by keyword, brand name or industry..." 
                className="pl-10 h-11"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
              />
            </div>
            <Button type="submit" className="h-11 px-8" disabled={isLoading}>
              {isLoading ? "Searching..." : "Search Ads"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array(6).fill(0).map((_, i) => (
            <Card key={i} className="border-none shadow-sm overflow-hidden h-96">
              <Skeleton className="h-48 w-full" />
              <CardContent className="p-4 space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))
        ) : !searchTrigger ? (
          <div className="col-span-full py-20 text-center bg-white dark:bg-gray-900 rounded-xl border-2 border-dashed border-border">
            <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold">Search for inspiration</h3>
            <p className="text-muted-foreground">Enter a keyword above to see active Meta ads.</p>
          </div>
        ) : ads?.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-white dark:bg-gray-900 rounded-xl border border-border">
            <h3 className="text-lg font-semibold">No ads found</h3>
            <p className="text-muted-foreground">Try a different search term.</p>
          </div>
        ) : (
          ads?.map((ad, idx) => (
            <Card key={idx} className="border-none shadow-sm hover:shadow-md transition-all overflow-hidden bg-white dark:bg-gray-900 flex flex-col">
              {ad.mediaUrl && (
                <div className="aspect-[4/5] w-full bg-muted relative overflow-hidden">
                  <img src={ad.mediaUrl} alt="Ad Preview" className="object-cover w-full h-full" />
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-blue-600 border-none">Active</Badge>
                  </div>
                </div>
              )}
              <CardContent className="p-4 flex-1 flex flex-col space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
                    {ad.advertiserName || "Advertiser"}
                  </span>
                  <Badge variant="outline" className="text-[10px]">
                    {ad.startDate ? `Started ${new Date(ad.startDate).toLocaleDateString()}` : "Ongoing"}
                  </Badge>
                </div>
                <p className="text-sm line-clamp-4 flex-1 italic text-muted-foreground">
                  "{ad.caption || "No ad text provided."}"
                </p>
                <div className="pt-3 border-t border-border/50">
                  <Badge variant="secondary" className="mb-2">{ad.mediaType}</Badge>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}

// ── TikTok Trending ─────────────────────────────────────────────────────
function TrendingContentSection() {
  const [industry, setIndustry] = useState("beauty");
  const { data: trending, isLoading } = useGetTrendingContent({ industry });

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-sm bg-white dark:bg-gray-900">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>TikTok Trending Content</CardTitle>
            <CardDescription>Viral content and trends by industry from TikHub.</CardDescription>
          </div>
          <Select value={industry} onValueChange={setIndustry}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="beauty">Beauty & Personal Care</SelectItem>
              <SelectItem value="food">Food & Beverage</SelectItem>
              <SelectItem value="fashion">Fashion & Apparel</SelectItem>
              <SelectItem value="tech">Technology</SelectItem>
              <SelectItem value="fitness">Health & Fitness</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading ? (
          Array(8).fill(0).map((_, i) => (
            <Card key={i} className="border-none shadow-sm h-80">
              <Skeleton className="h-full w-full" />
            </Card>
          ))
        ) : (
          trending?.map((item) => (
            <Card key={item.id} className="group border-none shadow-sm hover:shadow-lg transition-all overflow-hidden bg-black aspect-[9/16] relative">
              {item.thumbnailUrl && (
                <img src={item.thumbnailUrl} alt="Trend" className="object-cover w-full h-full opacity-80 group-hover:scale-105 transition-transform duration-500" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute top-3 left-3">
                <div className="h-8 w-8 rounded-full bg-primary/20 backdrop-blur-md flex items-center justify-center border border-white/20">
                  <Video className="h-4 w-4 text-white" />
                </div>
              </div>
              <div className="absolute bottom-4 left-4 right-4 space-y-2">
                <p className="text-white text-xs font-medium line-clamp-2">{item.title}</p>
                <div className="flex items-center gap-3 text-white/70 text-[10px]">
                  <span className="flex items-center gap-1"><ThumbsUp className="h-3 w-3" /> {item.likes || "0"}</span>
                  <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> {item.views || "0"}</span>
                </div>
              </div>
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                {item.videoUrl && (
                  <Button size="sm" variant="secondary" className="bg-white/20 hover:bg-white/40 border-white/30 text-white backdrop-blur-md" asChild>
                    <a href={item.videoUrl} target="_blank" rel="noopener noreferrer">View Trend</a>
                  </Button>
                )}
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}

// ── Social Crawl (MediaCrawler-inspired) ────────────────────────────────
type CrawlItem = {
  id: string;
  platform: string;
  type: string;
  title: string;
  authorName: string;
  likes: number;
  views: number;
  comments: number;
  thumbnailUrl: string;
  hashtags: string[];
  hotValue?: number;
  label?: string;
};

type CrawlResponse = {
  platform: string;
  keyword: string;
  source: "live" | "mock";
  note?: string;
  items: CrawlItem[];
};

function SocialCrawlSection() {
  const [activePlatform, setActivePlatform] = useState<"xhs" | "douyin">("xhs");
  const [keyword, setKeyword] = useState("美容");
  const [searchInput, setSearchInput] = useState("美容");

  const { data, isLoading, isFetching, refetch } = useQuery<CrawlResponse>({
    queryKey: ["social-crawl", activePlatform, keyword],
    queryFn: async () => {
      const res = await fetch(
        `${BASE}/api/market-data/social-crawl?platform=${activePlatform}&keyword=${encodeURIComponent(keyword)}&limit=12`,
      );
      return res.json() as Promise<CrawlResponse>;
    },
    staleTime: 3 * 60 * 1000,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setKeyword(searchInput);
  };

  const isMock = data?.source === "mock";

  return (
    <div className="space-y-6">
      {/* Header card */}
      <Card className="border-none shadow-sm bg-white dark:bg-gray-900">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Flame className="h-5 w-5 text-orange-500" />
                社交媒体爬虫 — 小红书 & 抖音热门
              </CardTitle>
              <CardDescription className="mt-1">
                抓取小红书笔记 & 抖音热搜，分析竞品内容风格（MediaCrawler 驱动）
              </CardDescription>
            </div>
            <button
              onClick={() => refetch()}
              disabled={isFetching}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              <RefreshCw className={cn("h-3.5 w-3.5", isFetching && "animate-spin")} />
              刷新
            </button>
          </div>

          {/* Platform tabs */}
          <div className="flex gap-2 mt-4">
            {(["xhs", "douyin"] as const).map((p) => (
              <button
                key={p}
                onClick={() => setActivePlatform(p)}
                className={cn(
                  "px-4 py-1.5 rounded-full text-sm font-medium transition-all border",
                  activePlatform === p
                    ? p === "xhs"
                      ? "bg-red-500 text-white border-red-500"
                      : "bg-black text-white border-black"
                    : "bg-white text-muted-foreground border-border hover:border-foreground/30",
                )}
              >
                {p === "xhs" ? "📕 小红书" : "🎵 抖音"}
              </button>
            ))}
          </div>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="flex gap-2 mt-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="搜索关键词（如：美容、护肤、美甲）"
                className="pl-10 h-10"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
              />
            </div>
            <Button type="submit" className="h-10 px-6" disabled={isLoading || isFetching}>
              {isFetching ? <RefreshCw className="h-4 w-4 animate-spin" /> : "搜索"}
            </Button>
          </form>
        </CardHeader>
      </Card>

      {/* Mock data notice */}
      {isMock && data?.note && (
        <div className="flex items-start gap-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/40 rounded-xl px-4 py-3">
          <Sparkles className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-800 dark:text-amber-300">示例数据模式</p>
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-0.5">{data.note}</p>
          </div>
        </div>
      )}

      {/* Results */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array(6).fill(0).map((_, i) => (
            <Card key={i} className="border-none shadow-sm overflow-hidden">
              <Skeleton className="h-40 w-full" />
              <CardContent className="p-4 space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : activePlatform === "douyin" ? (
        <DouyinHotList items={data?.items ?? []} />
      ) : (
        <XhsNoteGrid items={data?.items ?? []} />
      )}
    </div>
  );
}

function DouyinHotList({ items }: { items: CrawlItem[] }) {
  if (items.length === 0) return (
    <div className="py-20 text-center text-muted-foreground">暂无数据</div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      {items.map((item, i) => (
        <div
          key={item.id}
          className="flex items-center gap-4 p-4 bg-white dark:bg-gray-900 rounded-xl border border-border hover:shadow-md transition-all"
        >
          {/* Rank */}
          <div className={cn(
            "h-8 w-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0",
            i === 0 ? "bg-red-500 text-white" : i === 1 ? "bg-orange-400 text-white" : i === 2 ? "bg-yellow-400 text-white" : "bg-muted text-muted-foreground",
          )}>
            {i + 1}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="text-sm font-medium truncate">{item.title}</p>
              {item.label && (
                <Badge className={cn(
                  "text-[10px] px-1.5 py-0 shrink-0 border-0",
                  item.label === "爆" ? "bg-red-100 text-red-700" : item.label === "热" ? "bg-orange-100 text-orange-700" : "bg-blue-100 text-blue-700",
                )}>
                  {item.label}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground">
              <span className="flex items-center gap-1">
                <Flame className="h-3 w-3 text-orange-400" />
                {((item.hotValue ?? item.likes) / 10000).toFixed(0)}万热度
              </span>
              <span className="flex items-center gap-1">
                <Eye className="h-3 w-3" />
                {((item.views) / 10000).toFixed(0)}万播放
              </span>
            </div>
          </div>

          {/* Hashtag */}
          <div className="shrink-0">
            <Badge variant="secondary" className="text-[10px]">{item.hashtags[0]}</Badge>
          </div>
        </div>
      ))}
    </div>
  );
}

function XhsNoteGrid({ items }: { items: CrawlItem[] }) {
  if (items.length === 0) return (
    <div className="py-20 text-center text-muted-foreground">暂无数据</div>
  );

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {items.map((item) => (
        <Card key={item.id} className="group border-none shadow-sm hover:shadow-lg transition-all overflow-hidden bg-white dark:bg-gray-900">
          {/* Thumbnail */}
          <div className="relative h-44 bg-muted overflow-hidden">
            <img
              src={item.thumbnailUrl}
              alt={item.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
            <div className="absolute top-2 left-2">
              <Badge className="bg-red-500 border-0 text-[10px]">📕 小红书</Badge>
            </div>
            <div className="absolute bottom-2 left-2 right-2 flex gap-2 text-white text-[10px]">
              <span className="flex items-center gap-0.5"><ThumbsUp className="h-3 w-3" />{(item.likes / 1000).toFixed(0)}K</span>
              <span className="flex items-center gap-0.5"><MessageCircle className="h-3 w-3" />{item.comments}</span>
              <span className="flex items-center gap-0.5"><Eye className="h-3 w-3" />{(item.views / 10000).toFixed(0)}万</span>
            </div>
          </div>

          {/* Content */}
          <CardContent className="p-4 space-y-2">
            <p className="text-sm font-medium line-clamp-2 leading-snug">{item.title}</p>
            <p className="text-xs text-muted-foreground">{item.authorName}</p>
            <div className="flex flex-wrap gap-1 pt-1">
              {item.hashtags.slice(0, 3).map((tag) => (
                <Badge key={tag} variant="secondary" className="text-[10px] px-1.5 py-0">{tag}</Badge>
              ))}
            </div>
            <div className="pt-2 border-t border-border/50 flex items-center justify-between">
              <button className="flex items-center gap-1 text-xs text-primary hover:underline">
                <BookOpen className="h-3 w-3" /> 仿写此内容
              </button>
              <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
