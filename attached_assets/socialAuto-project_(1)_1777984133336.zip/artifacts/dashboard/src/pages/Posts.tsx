import {
  useListPosts,
  useCreatePost,
  useUpdatePost,
  useDeletePost,
  usePublishPost,
  useListAccounts,
  useListContentItems,
  getListPostsQueryKey,
  getGetPublishHistoryQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Plus, Trash2, Calendar as CalendarIcon, Clock, CheckCircle2,
  AlertCircle, Send, PlusCircle, Pencil, ChevronLeft, ChevronRight,
  Image as ImageIcon, Video, Facebook, Instagram, Info,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useState } from "react";
import { useLang } from "@/contexts/LanguageContext";
import {
  format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths
} from "date-fns";
import { cn } from "@/lib/utils";

const PLATFORM_OPTIONS = [
  { value: "facebook",  label: "Facebook",  icon: Facebook,  color: "text-blue-600",  bg: "bg-blue-50",  border: "border-blue-200" },
  { value: "instagram", label: "Instagram", icon: Instagram, color: "text-pink-600",  bg: "bg-pink-50",  border: "border-pink-200" },
  { value: "tiktok",    label: "TikTok",    icon: Video,     color: "text-gray-800",  bg: "bg-gray-100", border: "border-gray-200" },
];

export default function PostsPage() {
  const { t, lang } = useLang();
  const { data: posts, isLoading } = useListPosts();
  const createPost = useCreatePost();
  const updatePost = useUpdatePost();
  const deletePost = useDeletePost();
  const publishPost = usePublishPost();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [view, setView] = useState<"list" | "calendar">("list");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<any>(null);

  const handleDelete = (id: number) => {
    deletePost.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
        toast({ title: lang === "zh" ? "帖子已删除" : "Post deleted" });
      }
    });
  };

  const handlePublishNow = (id: number) => {
    publishPost.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetPublishHistoryQueryKey() });
        toast({
          title: lang === "zh" ? "发布中..." : "Publishing initiated",
          description: lang === "zh" ? "正在发送到各平台" : "Your post is being sent to social platforms."
        });
      }
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t.posts.title}</h1>
          <p className="text-muted-foreground mt-1">{t.posts.subtitle}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-muted/50 p-1 rounded-lg flex">
            <Button variant={view === "list" ? "secondary" : "ghost"} size="sm"
              className="rounded-md h-8 text-xs px-3" onClick={() => setView("list")}>
              {t.posts.listView}
            </Button>
            <Button variant={view === "calendar" ? "secondary" : "ghost"} size="sm"
              className="rounded-md h-8 text-xs px-3" onClick={() => setView("calendar")}>
              {t.posts.calendar}
            </Button>
          </div>
          <Button className="bg-primary" onClick={() => { setEditingPost(null); setIsCreateOpen(true); }}>
            <PlusCircle className="h-4 w-4 mr-2" />
            {t.posts.createPost}
          </Button>
        </div>
      </div>

      {/* Best posting times banner */}
      <Alert className="border-indigo-200 bg-indigo-50 dark:bg-indigo-950/20">
        <Info className="h-4 w-4 text-indigo-600" />
        <AlertDescription className="text-xs text-indigo-700 dark:text-indigo-300 space-y-0.5">
          <div><strong>Facebook:</strong> {t.posts.fbBestTime}</div>
          <div><strong>Instagram:</strong> {t.posts.igBestTime}</div>
          <div><strong>TikTok:</strong> {t.posts.tkBestTime}</div>
        </AlertDescription>
      </Alert>

      {view === "list" ? (
        <div className="space-y-4">
          {isLoading ? (
            Array(5).fill(0).map((_, i) => (
              <Card key={i} className="border-none shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-12 w-12 rounded-lg" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-1/4" />
                      <Skeleton className="h-3 w-3/4" />
                    </div>
                    <Skeleton className="h-8 w-24 rounded-full" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : posts?.length === 0 ? (
            <Card className="border-2 border-dashed border-border bg-white dark:bg-gray-900 py-20 text-center">
              <CardContent>
                <CalendarIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold">{t.posts.noScheduled}</h3>
                <p className="text-muted-foreground">{t.posts.noScheduledDesc}</p>
                <Button className="mt-4" onClick={() => setIsCreateOpen(true)}>{t.posts.createPost}</Button>
              </CardContent>
            </Card>
          ) : (
            posts?.map((post) => (
              <PostListItem
                key={post.id}
                post={post}
                lang={lang}
                onEdit={() => { setEditingPost(post); setIsCreateOpen(true); }}
                onDelete={() => handleDelete(post.id)}
                onPublish={() => handlePublishNow(post.id)}
                isPublishing={publishPost.isPending && (publishPost.variables as any)?.id === post.id}
              />
            ))
          )}
        </div>
      ) : (
        <CalendarView posts={posts || []} onPostClick={(post) => {
          setEditingPost(post);
          setIsCreateOpen(true);
        }} />
      )}

      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingPost
                ? (lang === "zh" ? "编辑帖子" : "Edit Post")
                : (lang === "zh" ? "创建新帖子" : "Create New Post")}
            </DialogTitle>
          </DialogHeader>
          <PostForm
            post={editingPost}
            lang={lang}
            onComplete={() => {
              setIsCreateOpen(false);
              queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PostListItem({ post, lang, onEdit, onDelete, onPublish, isPublishing }: any) {
  const platforms: string[] = Array.isArray(post.platforms) ? post.platforms : [];
  const mediaUrl = Array.isArray(post.mediaUrls) ? post.mediaUrls[0] : null;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "published": return <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-green-200"><CheckCircle2 className="h-3 w-3 mr-1" /> {status}</Badge>;
      case "failed":    return <Badge variant="destructive" className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200"><AlertCircle className="h-3 w-3 mr-1" /> {status}</Badge>;
      case "scheduled": return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200"><Clock className="h-3 w-3 mr-1" /> {status}</Badge>;
      default:          return <Badge variant="outline" className="bg-gray-100 text-gray-700">{status}</Badge>;
    }
  };

  return (
    <Card className="border-none shadow-sm hover:shadow-md transition-all bg-white dark:bg-gray-900 group">
      <CardContent className="p-0">
        <div className="flex flex-col md:flex-row">
          <div className="w-full md:w-40 h-28 bg-muted relative overflow-hidden flex-shrink-0">
            {mediaUrl ? (
              <img src={mediaUrl} alt="Media" className="object-cover w-full h-full" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-muted-foreground/30">
                <ImageIcon className="h-8 w-8" />
              </div>
            )}
            <div className="absolute top-2 left-2 flex gap-1 flex-wrap">
              {platforms.map((p: string) => {
                const opt = PLATFORM_OPTIONS.find((o) => o.value === p);
                if (!opt) return null;
                const Icon = opt.icon;
                return (
                  <div key={p} className={cn("h-5 w-5 rounded flex items-center justify-center", opt.bg)}>
                    <Icon className={cn("h-3 w-3", opt.color)} />
                  </div>
                );
              })}
            </div>
          </div>
          <div className="flex-1 p-4 md:p-5 flex flex-col justify-between min-w-0">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  {getStatusBadge(post.status)}
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <CalendarIcon className="h-3 w-3" />
                    {post.scheduledAt ? format(new Date(post.scheduledAt), "MMM d, h:mm a") : (lang === "zh" ? "草稿" : "Draft")}
                  </span>
                </div>
                <p className="text-sm line-clamp-2 leading-relaxed">{post.caption}</p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {post.status !== "published" && (
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-primary" onClick={onPublish} disabled={isPublishing}>
                    <Send className={cn("h-4 w-4", isPublishing && "animate-pulse")} />
                  </Button>
                )}
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onEdit}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={onDelete}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function CalendarView({ posts, onPostClick }: { posts: any[]; onPostClick: (post: any) => void }) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  return (
    <Card className="border-none shadow-sm bg-white dark:bg-gray-900 overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between border-b border-border/50 bg-gray-50/50">
        <CardTitle className="text-lg">{format(currentDate, "MMMM yyyy")}</CardTitle>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8"
            onClick={() => setCurrentDate(subMonths(currentDate, 1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" className="h-8 px-3 text-xs"
            onClick={() => setCurrentDate(new Date())}>Today</Button>
          <Button variant="ghost" size="icon" className="h-8 w-8"
            onClick={() => setCurrentDate(addMonths(currentDate, 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="grid grid-cols-7 border-b border-border/50">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
            <div key={day} className="p-3 text-center text-xs font-bold text-muted-foreground uppercase tracking-wider bg-gray-50/30">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 auto-rows-[120px]">
          {Array(monthStart.getDay()).fill(0).map((_, i) => (
            <div key={`empty-${i}`} className="border-r border-b border-border/30 bg-gray-50/10" />
          ))}
          {days.map((day) => {
            const dayPosts = posts.filter((p) =>
              p.scheduledAt && isSameDay(new Date(p.scheduledAt), day)
            );
            return (
              <div key={day.toString()}
                className="p-2 border-r border-b border-border/30 hover:bg-muted/10 transition-colors relative">
                <span className={cn(
                  "text-xs font-medium inline-flex items-center justify-center h-6 w-6 rounded-full mb-1",
                  isSameDay(day, new Date()) ? "bg-primary text-white shadow-sm" : "text-muted-foreground"
                )}>
                  {format(day, "d")}
                </span>
                <div className="space-y-0.5">
                  {dayPosts.map((post) => {
                    const platforms: string[] = Array.isArray(post.platforms) ? post.platforms : [];
                    const primary = platforms[0] ?? "facebook";
                    return (
                      <div key={post.id}
                        className={cn(
                          "text-[10px] p-1 rounded border-l-2 truncate cursor-pointer hover:brightness-95",
                          primary === "facebook" ? "bg-blue-50 text-blue-700 border-blue-500" :
                          primary === "instagram" ? "bg-pink-50 text-pink-700 border-pink-500" :
                          "bg-gray-100 text-gray-700 border-gray-500"
                        )}
                        onClick={() => onPostClick(post)}
                      >
                        {post.caption}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

function PostForm({ post, lang, onComplete }: { post: any; lang: string; onComplete: () => void }) {
  const createPost = useCreatePost();
  const updatePost = useUpdatePost();
  const { toast } = useToast();
  const isZh = lang === "zh";
  const { t } = useLang();

  const defaultPlatforms = Array.isArray(post?.platforms) ? post.platforms : ["facebook"];
  const defaultMediaUrl = Array.isArray(post?.mediaUrls) ? post.mediaUrls[0] ?? "" : "";

  const form = useForm({
    defaultValues: {
      caption:     post?.caption || "",
      platforms:   defaultPlatforms as string[],
      mediaUrl:    defaultMediaUrl,
      scheduledAt: post?.scheduledAt ? new Date(post.scheduledAt).toISOString().slice(0, 16) : "",
    }
  });

  const selectedPlatforms: string[] = form.watch("platforms");

  const togglePlatform = (platform: string) => {
    const current = form.getValues("platforms");
    if (current.includes(platform)) {
      if (current.length > 1) form.setValue("platforms", current.filter((p) => p !== platform));
    } else {
      form.setValue("platforms", [...current, platform]);
    }
  };

  const onSubmit = (data: { caption: string; platforms: string[]; mediaUrl: string; scheduledAt: string }) => {
    const payload = {
      caption: data.caption,
      platforms: data.platforms,
      mediaUrls: data.mediaUrl ? [data.mediaUrl] : [],
      scheduledAt: data.scheduledAt ? new Date(data.scheduledAt).toISOString() : undefined,
    };

    if (post) {
      updatePost.mutate({ id: post.id, data: payload }, {
        onSuccess: () => { toast({ title: isZh ? "帖子已更新" : "Post updated" }); onComplete(); }
      });
    } else {
      createPost.mutate({ data: payload }, {
        onSuccess: () => { toast({ title: isZh ? "帖子已排程" : "Post scheduled" }); onComplete(); }
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 pt-2">

        {/* Platform multi-select */}
        <div className="space-y-2">
          <label className="text-sm font-medium">{t.posts.platforms}</label>
          <div className="flex gap-2 flex-wrap">
            {PLATFORM_OPTIONS.map((opt) => {
              const Icon = opt.icon;
              const selected = selectedPlatforms.includes(opt.value);
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => togglePlatform(opt.value)}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium transition-all",
                    selected
                      ? `${opt.bg} ${opt.border} ${opt.color} shadow-sm`
                      : "border-border bg-background text-muted-foreground hover:border-border/80"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {opt.label}
                  {selected && <CheckCircle2 className="h-3.5 w-3.5" />}
                </button>
              );
            })}
          </div>
          <p className="text-xs text-muted-foreground">
            {isZh ? "可同时选择多个平台，一次发布" : "Select multiple platforms to publish simultaneously"}
          </p>
        </div>

        {/* Caption */}
        <FormField control={form.control} name="caption" render={({ field }) => (
          <FormItem>
            <FormLabel>{t.posts.caption}</FormLabel>
            <FormControl>
              <Textarea
                placeholder={isZh ? "输入帖子文案... #话题标签" : "Write your post caption... #hashtags"}
                className="min-h-[120px]"
                {...field}
              />
            </FormControl>
            <FormDescription className="text-xs">
              {field.value.length} / 2200 {isZh ? "字符" : "chars"}
            </FormDescription>
            <FormMessage />
          </FormItem>
        )} />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Media URL */}
          <FormField control={form.control} name="mediaUrl" render={({ field }) => (
            <FormItem>
              <FormLabel>{t.posts.mediaUrl}</FormLabel>
              <FormControl>
                <Input placeholder="https://..." {...field} />
              </FormControl>
              <FormDescription className="text-xs">
                {isZh ? "支持 MP4 视频或图片链接" : "MP4 video or image URL"}
              </FormDescription>
              <FormMessage />
            </FormItem>
          )} />

          {/* Schedule time */}
          <FormField control={form.control} name="scheduledAt" render={({ field }) => (
            <FormItem>
              <FormLabel>{t.posts.scheduleTime}</FormLabel>
              <FormControl>
                <Input type="datetime-local" {...field} />
              </FormControl>
              <FormDescription className="text-xs">
                {isZh ? "留空则保存为草稿" : "Leave blank to save as draft"}
              </FormDescription>
              <FormMessage />
            </FormItem>
          )} />
        </div>

        {/* Best time hint based on selected platforms */}
        {selectedPlatforms.length > 0 && (
          <div className="rounded-lg bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800 p-3 space-y-1">
            <p className="text-xs font-semibold text-indigo-700 dark:text-indigo-300 flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              {t.posts.bestTimes}
            </p>
            {selectedPlatforms.includes("facebook") && (
              <p className="text-xs text-indigo-600 dark:text-indigo-400">📘 {t.posts.fbBestTime}</p>
            )}
            {selectedPlatforms.includes("instagram") && (
              <p className="text-xs text-indigo-600 dark:text-indigo-400">📸 {t.posts.igBestTime}</p>
            )}
            {selectedPlatforms.includes("tiktok") && (
              <p className="text-xs text-indigo-600 dark:text-indigo-400">🎵 {t.posts.tkBestTime}</p>
            )}
          </div>
        )}

        <DialogFooter className="pt-2">
          <Button
            type="submit"
            className="w-full"
            disabled={createPost.isPending || updatePost.isPending}
          >
            {(createPost.isPending || updatePost.isPending)
              ? (isZh ? "保存中..." : "Saving...")
              : post
              ? t.posts.updatePost
              : form.watch("scheduledAt")
              ? t.posts.schedulePost
              : t.posts.publishNow}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
