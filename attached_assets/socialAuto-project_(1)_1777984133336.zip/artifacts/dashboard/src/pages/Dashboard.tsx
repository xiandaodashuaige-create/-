import {
  useGetAnalyticsSummary,
  useGetPublishHistory,
  useListAccounts,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  TrendingUp,
  Users,
  Share2,
  CheckCircle2,
  Clock,
  AlertCircle,
  BarChart3,
  Bot,
  Zap,
  ArrowRight,
  Settings,
  UserPlus,
  Calendar,
  Sparkles,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { useLang } from "@/contexts/LanguageContext";
import { Link } from "wouter";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

export default function DashboardPage() {
  const { t, lang } = useLang();
  const { data: summary, isLoading: isSummaryLoading } = useGetAnalyticsSummary();
  const { data: history, isLoading: isHistoryLoading } = useGetPublishHistory();
  const { data: accounts } = useListAccounts();
  const [onboardingDismissed, setOnboardingDismissed] = useState(() =>
    localStorage.getItem("sa_onboarding_dismissed") === "1"
  );

  const dismissOnboarding = () => {
    setOnboardingDismissed(true);
    localStorage.setItem("sa_onboarding_dismissed", "1");
  };

  const hasAccounts = (accounts?.length ?? 0) > 0;
  const hasPosts = (summary?.totalScheduledPosts ?? 0) > 0;
  const hasContent = (summary?.totalContentItems ?? 0) > 0;

  const setupSteps = [
    {
      icon: Settings,
      title: t.dashboard.step1Title,
      desc: t.dashboard.step1Desc,
      done: hasAccounts,
      href: "/accounts",
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
    {
      icon: UserPlus,
      title: t.dashboard.step2Title,
      desc: t.dashboard.step2Desc,
      done: (summary?.totalCompetitors ?? 0) > 0,
      href: "/competitors",
      color: "text-purple-600",
      bg: "bg-purple-50",
    },
    {
      icon: Calendar,
      title: t.dashboard.step3Title,
      desc: t.dashboard.step3Desc,
      done: hasPosts,
      href: "/posts",
      color: "text-pink-600",
      bg: "bg-pink-50",
    },
    {
      icon: Bot,
      title: t.dashboard.step4Title,
      desc: t.dashboard.step4Desc,
      done: false,
      href: "/ai-autopilot",
      color: "text-indigo-600",
      bg: "bg-indigo-50",
    },
  ];

  const stepsCompleted = setupSteps.filter((s) => s.done).length;
  const allDone = stepsCompleted === setupSteps.length - 1;
  const showOnboarding = !onboardingDismissed && stepsCompleted < 3;

  const stats = [
    {
      label: t.dashboard.totalAccounts,
      value: summary?.totalAccounts?.toLocaleString(),
      icon: Users,
      trend: hasAccounts ? "✓" : lang === "zh" ? "未连接" : "Not connected",
      color: "text-blue-600",
      trendColor: hasAccounts ? "text-green-600" : "text-orange-500",
    },
    {
      label: t.dashboard.upcomingPosts,
      value: summary?.upcomingPosts?.toLocaleString(),
      icon: TrendingUp,
      trend: "+8.2%",
      color: "text-purple-600",
      trendColor: "text-green-600",
    },
    {
      label: t.dashboard.totalContent,
      value: summary?.totalContentItems?.toLocaleString(),
      icon: Share2,
      trend: "+5.1%",
      color: "text-pink-600",
      trendColor: "text-green-600",
    },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "success":
        return <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-green-200"><CheckCircle2 className="h-3 w-3 mr-1" /> {t.common.success}</Badge>;
      case "failed":
        return <Badge variant="destructive" className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200"><AlertCircle className="h-3 w-3 mr-1" /> {t.common.failed}</Badge>;
      default:
        return <Badge variant="outline" className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200"><Clock className="h-3 w-3 mr-1" /> {status}</Badge>;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t.dashboard.title}</h1>
          <p className="text-muted-foreground mt-1">{t.dashboard.subtitle}</p>
        </div>
      </div>

      {/* ── Onboarding checklist ─────────────────────────────────── */}
      {showOnboarding && (
        <Card className="border-none shadow-sm bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30 overflow-hidden relative">
          <button
            onClick={dismissOnboarding}
            className="absolute top-4 right-4 h-6 w-6 rounded-full flex items-center justify-center text-muted-foreground hover:bg-black/10 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-indigo-600 flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-lg">{t.dashboard.onboardingTitle}</CardTitle>
                <CardDescription>{t.dashboard.onboardingSubtitle}</CardDescription>
              </div>
            </div>
            <div className="mt-3 flex items-center gap-3">
              <Progress value={(stepsCompleted / (setupSteps.length - 1)) * 100} className="h-2 flex-1" />
              <span className="text-xs font-medium text-muted-foreground whitespace-nowrap">
                {stepsCompleted} / {setupSteps.length - 1}
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {setupSteps.map((step, i) => (
                <Link key={i} href={step.href}>
                  <div className={cn(
                    "rounded-xl border bg-white/80 dark:bg-gray-900/60 p-3 cursor-pointer transition-all hover:shadow-sm",
                    step.done ? "border-green-200 opacity-70" : "border-border hover:border-indigo-300"
                  )}>
                    <div className="flex items-start justify-between mb-2">
                      <div className={cn("h-8 w-8 rounded-lg flex items-center justify-center", step.bg)}>
                        {step.done
                          ? <CheckCircle2 className="h-4 w-4 text-green-600" />
                          : <step.icon className={cn("h-4 w-4", step.color)} />}
                      </div>
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                        {lang === "zh" ? `步骤 ${i + 1}` : `Step ${i + 1}`}
                      </Badge>
                    </div>
                    <p className="text-xs font-semibold leading-tight">{step.title}</p>
                    <p className="text-[11px] text-muted-foreground mt-1 leading-tight">{step.desc}</p>
                    {!step.done && (
                      <div className={cn("mt-2 text-[11px] font-medium flex items-center gap-1", step.color)}>
                        {lang === "zh" ? "去设置" : "Set up"}
                        <ArrowRight className="h-3 w-3" />
                      </div>
                    )}
                  </div>
                </Link>
              ))}
            </div>
            <p className="text-xs text-muted-foreground text-center mt-3">
              <button onClick={dismissOnboarding} className="underline underline-offset-2 hover:text-foreground transition-colors">
                {t.dashboard.onboardingDismiss}
              </button>
            </p>
          </CardContent>
        </Card>
      )}

      {/* ── AI Autopilot hero CTA ────────────────────────────────── */}
      <div className="relative overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600" />
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)", backgroundSize: "40px 40px" }} />
        <div className="relative p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center shrink-0">
              <Bot className="h-7 w-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-lg font-bold text-white">{t.dashboard.aiHeroTitle}</h3>
                <Zap className="h-4 w-4 text-yellow-300 animate-pulse shrink-0" />
              </div>
              <p className="text-white/70 text-sm">{t.dashboard.aiHeroDesc}</p>
            </div>
          </div>
          <Link href="/ai-autopilot">
            <Button className="bg-white text-indigo-700 hover:bg-white/90 shrink-0 shadow-lg font-semibold">
              {t.dashboard.aiHeroBtn}
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>

      {/* ── Stats row ────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {isSummaryLoading ? (
          Array(3).fill(0).map((_, i) => (
            <Card key={i} className="shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-4 rounded-full" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-1" />
                <Skeleton className="h-3 w-20" />
              </CardContent>
            </Card>
          ))
        ) : (
          stats.map((stat) => (
            <Card key={stat.label} className="shadow-sm hover:shadow-md transition-shadow border-none bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-950">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.label}</CardTitle>
                <stat.icon className={cn("h-4 w-4", stat.color)} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value ?? 0}</div>
                <p className={cn("text-xs font-medium mt-1", stat.trendColor)}>
                  {stat.trend}
                </p>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* ── Recent activity ──────────────────────────────────────── */}
      <Card className="shadow-sm border-none bg-white dark:bg-gray-900 overflow-hidden">
        <CardHeader className="border-b border-border/50 bg-gray-50/30">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl">{t.dashboard.recentActivity}</CardTitle>
              <CardDescription>{t.dashboard.recentActivityDesc}</CardDescription>
            </div>
            <BarChart3 className="h-5 w-5 text-muted-foreground" />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50 text-muted-foreground">
                  <th className="text-left font-medium p-4 border-b border-border">{t.dashboard.platform}</th>
                  <th className="text-left font-medium p-4 border-b border-border">{t.dashboard.date}</th>
                  <th className="text-left font-medium p-4 border-b border-border">{t.dashboard.status}</th>
                  <th className="text-left font-medium p-4 border-b border-border">{t.dashboard.error}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {isHistoryLoading ? (
                  Array(5).fill(0).map((_, i) => (
                    <tr key={i}>
                      <td className="p-4"><Skeleton className="h-4 w-20" /></td>
                      <td className="p-4"><Skeleton className="h-4 w-24" /></td>
                      <td className="p-4"><Skeleton className="h-6 w-20 rounded-full" /></td>
                      <td className="p-4"><Skeleton className="h-4 w-32" /></td>
                    </tr>
                  ))
                ) : history?.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-8 text-center text-muted-foreground">
                      {t.dashboard.noHistory}
                    </td>
                  </tr>
                ) : (
                  history?.map((log) => (
                    <tr key={log.id} className="hover:bg-muted/30 transition-colors">
                      <td className="p-4">
                        <Badge variant="outline" className="capitalize">{log.platform}</Badge>
                      </td>
                      <td className="p-4 text-muted-foreground">
                        {log.publishedAt ? format(new Date(log.publishedAt), "MMM d, h:mm a") : "N/A"}
                      </td>
                      <td className="p-4">{getStatusBadge(log.status)}</td>
                      <td className="p-4 text-xs text-muted-foreground italic">
                        {log.errorMessage || "—"}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
