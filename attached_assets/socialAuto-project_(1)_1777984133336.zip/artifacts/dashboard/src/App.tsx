import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AppLayout } from "@/components/layout/AppLayout";
import DashboardPage from "@/pages/Dashboard";
import AccountsPage from "@/pages/Accounts";
import CompetitorsPage from "@/pages/Competitors";
import MarketDataPage from "@/pages/MarketData";
import ContentLibraryPage from "@/pages/ContentLibrary";
import PostsPage from "@/pages/Posts";
import AiAutopilotPage from "@/pages/AiAutopilot";
import { LanguageProvider } from "@/contexts/LanguageContext";

const queryClient = new QueryClient();

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={DashboardPage} />
        <Route path="/accounts" component={AccountsPage} />
        <Route path="/competitors" component={CompetitorsPage} />
        <Route path="/market-data" component={MarketDataPage} />
        <Route path="/content" component={ContentLibraryPage} />
        <Route path="/posts" component={PostsPage} />
        <Route path="/ai-autopilot" component={AiAutopilotPage} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <LanguageProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </LanguageProvider>
  );
}

export default App;
