# SocialAuto — Social Media Automation Platform

A full-stack SaaS platform helping small business owners (beauty, restaurant industries) monitor competitors, manage content, and auto-schedule posts on Facebook and TikTok.

## Architecture

**Monorepo (pnpm workspace)**

```
artifacts/
  api-server/     — Express 5 backend (port 8080, serves /api)
  dashboard/      — React + Vite frontend (port 23183, serves /)
lib/
  api-spec/       — OpenAPI 3.1 spec + orval codegen config
  api-zod/        — Generated Zod validation schemas (server-side)
  api-client-react/ — Generated React Query hooks (client-side)
  db/             — Drizzle ORM schema + pg client
```

## Key Features

1. **中英双语** — Language toggle (中文/EN), persisted in localStorage via LanguageContext
2. **AI自动驾驶** — Animated autopilot page: 5-step pipeline (scan → analyze → generate → schedule → publish) with live log stream, typewriter captions, progress indicators
3. **竞品监控** — Add Facebook/TikTok competitor pages; fetch their posts
4. **市场数据** — Meta Ad Library search + TikHub trending content discovery
5. **内容库** — Upload/manage images, videos, text; AI caption generation (GPT-4o-mini)
6. **定时发布** — Create posts, schedule them, publish via Ayrshare API (Facebook + TikTok)
7. **数据看板** — Analytics summary, publish history, status breakdown
8. **授权完善** — Facebook OAuth 2.0 flow (`/api/auth/facebook/connect` → callback → auto-save pages); TikTok via Ayrshare profile link (`/api/auth/ayrshare/link`)

## Database Tables (PostgreSQL via Drizzle ORM)

- `social_accounts` — Connected social media accounts
- `competitors` — Monitored competitor pages
- `competitor_posts` — Fetched posts from competitors
- `content_items` — Content library (text/image/video)
- `scheduled_posts` — Posts queue with status tracking
- `publish_logs` — Full publish history

## API Routes

| Domain | Endpoints |
|--------|-----------|
| Accounts | GET/POST `/api/accounts`, DELETE `/api/accounts/:id` |
| Competitors | GET/POST `/api/competitors`, DELETE, GET `/api/competitors/:id/posts` |
| Market Data | GET `/api/market-data/ads`, GET `/api/market-data/trending` |
| Content | GET/POST `/api/content`, DELETE, POST `/api/content/generate-caption` |
| Posts | GET/POST `/api/posts`, GET/PATCH/DELETE `/api/posts/:id`, POST `/api/posts/:id/publish` |
| Analytics | GET `/api/analytics/summary`, GET `/api/analytics/publish-history` |

## Environment Variables (Optional)

| Variable | Purpose |
|----------|---------|
| `FACEBOOK_ACCESS_TOKEN` | Meta Ad Library API access |
| `TIKHUB_API_KEY` | TikHub trending content API |
| `AYRSHARE_API_KEY` | Multi-platform publishing (Facebook + TikTok) |
| `OPENAI_API_KEY` | AI caption generation |
| `SESSION_SECRET` | Express session security |

> All external APIs fall back to realistic mock data when keys are not configured.

## Codegen

After changing `lib/api-spec/openapi.yaml`, run:
```bash
pnpm --filter @workspace/api-spec run codegen
```

## DB Schema Changes

```bash
pnpm --filter @workspace/db run push
```
