import { pgTable, serial, text, timestamp, jsonb, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const socialAccountsTable = pgTable("social_accounts", {
  id: serial("id").primaryKey(),
  customerId: text("customer_id").notNull().default("default"),
  platform: text("platform").notNull(),
  accountId: text("account_id").notNull().default(""),
  accountName: text("account_name").notNull().default(""),
  accessToken: text("access_token").notNull().default(""),
  tokenExpiresAt: timestamp("token_expires_at"),
  refreshToken: text("refresh_token"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("uq_customer_platform_account").on(
    table.customerId,
    table.platform,
    table.accountId,
  ),
]);

export const insertSocialAccountSchema = createInsertSchema(socialAccountsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertSocialAccount = z.infer<typeof insertSocialAccountSchema>;
export type SocialAccount = typeof socialAccountsTable.$inferSelect;
