import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const competitorPostsTable = pgTable("competitor_posts", {
  id: serial("id").primaryKey(),
  competitorId: integer("competitor_id").notNull(),
  platform: text("platform").notNull(),
  postUrl: text("post_url"),
  caption: text("caption"),
  mediaType: text("media_type").notNull().default("text"),
  mediaUrls: text("media_urls").array(),
  likes: integer("likes").default(0),
  comments: integer("comments").default(0),
  shares: integer("shares").default(0),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  fetchedAt: timestamp("fetched_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCompetitorPostSchema = createInsertSchema(competitorPostsTable).omit({ id: true, fetchedAt: true });
export type InsertCompetitorPost = z.infer<typeof insertCompetitorPostSchema>;
export type CompetitorPost = typeof competitorPostsTable.$inferSelect;
