import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const contentItemsTable = pgTable("content_items", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  caption: text("caption"),
  mediaUrl: text("media_url"),
  thumbnailUrl: text("thumbnail_url"),
  industry: text("industry"),
  tags: text("tags").array(),
  sourceType: text("source_type").notNull().default("uploaded"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertContentItemSchema = createInsertSchema(contentItemsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertContentItem = z.infer<typeof insertContentItemSchema>;
export type ContentItem = typeof contentItemsTable.$inferSelect;
