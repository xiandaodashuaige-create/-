import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const publishLogsTable = pgTable("publish_logs", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  platform: text("platform").notNull(),
  status: text("status").notNull(),
  ayrsharePostId: text("ayrshare_post_id"),
  errorMessage: text("error_message"),
  publishedAt: timestamp("published_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertPublishLogSchema = createInsertSchema(publishLogsTable).omit({ id: true, publishedAt: true });
export type InsertPublishLog = z.infer<typeof insertPublishLogSchema>;
export type PublishLog = typeof publishLogsTable.$inferSelect;
